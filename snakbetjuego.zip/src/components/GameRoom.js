import React, { useState, useEffect } from 'react';
import GameCanvas from './GameCanvas';
import GameControls from './GameControls';
import { userStorage, currentRoomStorage, playerStatsStorage, systemCommissionStorage } from '../utilities/storage';
import snakeSkins from '../mock/snakeSkins';

const GameRoom = ({ room, onExit }) => {
  const [gameState, setGameState] = useState(null);
  const [playerId, setPlayerId] = useState(null);
  const [countdown, setCountdown] = useState(null);
  const [gameStatus, setGameStatus] = useState('waiting'); // waiting, starting, playing, finished
  const [playerRank, setPlayerRank] = useState(null);
  const [playersLeft, setPlayersLeft] = useState(0);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);
  const [survivalTimeRemaining, setSurvivalTimeRemaining] = useState(null);
  const [survivors, setSurvivors] = useState([]);
  
  // Inicializar el juego
  useEffect(() => {
    // Generar ID de jugador
    const newPlayerId = 'player_' + Math.random().toString(36).substr(2, 9);
    setPlayerId(newPlayerId);
    
    // Simular unirse a la sala
    const updatedRoom = { ...room };
    updatedRoom.currentPlayers += 1;
    
    // Si hay suficientes jugadores para iniciar, comenzar cuenta regresiva
    if (updatedRoom.currentPlayers >= updatedRoom.minPlayersToStart) {
      setGameStatus('starting');
      setCountdown(5);
    } else {
      setGameStatus('waiting');
    }
    
    currentRoomStorage.setStorage(updatedRoom);
    
    // Inicializar estado del juego
    const initialGameState = {
      mapSize: 30, // Tamaño del mapa 30x30
      shrinkFactor: 1, // Factor de encogimiento (1 = tamaño completo)
      nextShrinkTime: Date.now() + 60000, // Próximo encogimiento en 60 segundos
      food: [
        { x: 5, y: 5 },
        { x: 15, y: 15 },
        { x: 25, y: 25 },
      ],
      obstacles: [],
      players: [],
      gameMode: room.gameMode
    };
    
    // Si es modo supervivencia, añadir tiempo de supervivencia
    if (room.gameMode === 'survival') {
      initialGameState.survivalTime = room.survivalTime;
      initialGameState.survivalTimeRemaining = room.survivalTime;
      setSurvivalTimeRemaining(room.survivalTime);
    }
    
    // Añadir jugadores simulados
    for (let i = 0; i < 10; i++) {
      const x = Math.floor(Math.random() * initialGameState.mapSize);
      const y = Math.floor(Math.random() * initialGameState.mapSize);
      
      // Asignar un skin aleatorio a cada jugador
      const randomSkinId = Math.floor(Math.random() * snakeSkins.length) + 1;
      
      initialGameState.players.push({
        id: i === 0 ? newPlayerId : 'bot_' + i,
        name: i === 0 ? 'Tú' : 'Bot ' + i,
        snake: {
          body: [
            { x, y },
            { x: x-1, y },
            { x: x-2, y }
          ],
          direction: 'right',
          length: 3
        },
        score: 0,
        isAlive: true,
        skinId: i === 0 ? (userStorage.getStorage().selectedSkin || 1) : randomSkinId
      });
    }
    
    setGameState(initialGameState);
    setPlayersLeft(initialGameState.players.length);
    
    // Limpiar al salir
    return () => {
      currentRoomStorage.clearStorage();
    };
  }, [room]);
  
  // Cuenta regresiva para iniciar el juego
  useEffect(() => {
    if (gameStatus !== 'starting' || countdown === null) return;
    
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setGameStatus('playing');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [gameStatus, countdown]);
  
  // Lógica del juego
  useEffect(() => {
    if (gameStatus !== 'playing' || !gameState) return;
    
    const gameLoop = setInterval(() => {
      setGameState(prevState => {
        if (!prevState) return null;
        
        const newState = { ...prevState };
        
        // Actualizar tiempo de supervivencia si es modo supervivencia
        if (newState.gameMode === 'survival' && newState.survivalTimeRemaining > 0) {
          newState.survivalTimeRemaining -= 1;
          setSurvivalTimeRemaining(newState.survivalTimeRemaining);
          
          // Si el tiempo llega a cero, finalizar el juego con supervivientes
          if (newState.survivalTimeRemaining === 0) {
            const survivors = newState.players.filter(p => p.isAlive);
            setSurvivors(survivors);
            
            // Si el jugador actual sobrevivió
            if (survivors.some(p => p.id === playerId)) {
              // Calcular premio compartido
              const totalPrize = room.entryFee * room.maxPlayers;
              const systemCommission = totalPrize * 0.1; // 10% de comisión
              const prizePool = totalPrize - systemCommission;
              const prizePerSurvivor = prizePool / survivors.length;
              
              // Actualizar estadísticas
              const stats = playerStatsStorage.getStorage();
              const updatedStats = { ...stats };
              updatedStats.survivalWins += 1;
              updatedStats.earnings += prizePerSurvivor;
              
              // Actualizar balance
              const user = userStorage.getStorage();
              userStorage.setStorage({
                ...user,
                token: user.token + prizePerSurvivor
              });
              
              playerStatsStorage.setStorage(updatedStats);
            }
            
            setGameStatus('finished');
          }
        }
        
        // Mover serpientes
        newState.players = newState.players.map(player => {
          if (!player.isAlive) return player;
          
          const newPlayer = { ...player };
          const head = { ...newPlayer.snake.body[0] };
          
          // Mover cabeza según dirección
          switch (newPlayer.snake.direction) {
            case 'up':
              head.y -= 1;
              break;
            case 'down':
              head.y += 1;
              break;
            case 'left':
              head.x -= 1;
              break;
            case 'right':
              head.x += 1;
              break;
            default:
              break;
          }
          
          // Comprobar colisiones con los bordes del mapa
          if (
            head.x < 0 || 
            head.x >= newState.mapSize || 
            head.y < 0 || 
            head.y >= newState.mapSize
          ) {
            newPlayer.isAlive = false;
            return newPlayer;
          }
          
          // Comprobar colisiones con los límites de encogimiento
          const shrinkBorder = Math.floor(newState.mapSize * (1 - newState.shrinkFactor) / 2);
          if (
            head.x < shrinkBorder || 
            head.x >= newState.mapSize - shrinkBorder || 
            head.y < shrinkBorder || 
            head.y >= newState.mapSize - shrinkBorder
          ) {
            newPlayer.isAlive = false;
            return newPlayer;
          }
          
          // Comprobar colisiones con obstáculos
          if (newState.obstacles.some(obs => obs.x === head.x && obs.y === head.y)) {
            newPlayer.isAlive = false;
            return newPlayer;
          }
          
          // Comprobar colisiones con otras serpientes
          for (const otherPlayer of newState.players) {
            // Colisión con cuerpo de otras serpientes o con el propio cuerpo (excepto la cola que se moverá)
            const collidesWithBody = otherPlayer.snake.body.some((segment, index) => {
              // Ignorar la cola si no ha comido (porque se moverá)
              if (otherPlayer.id === newPlayer.id && index === otherPlayer.snake.body.length - 1) {
                return false;
              }
              return segment.x === head.x && segment.y === head.y;
            });
            
            if (collidesWithBody) {
              newPlayer.isAlive = false;
              
              // Si colisiona con otra serpiente, aumentar puntuación del otro jugador
              if (otherPlayer.id !== newPlayer.id) {
                const playerIndex = newState.players.findIndex(p => p.id === otherPlayer.id);
                if (playerIndex !== -1) {
                  newState.players[playerIndex].score += 10;
                }
              }
              
              return newPlayer;
            }
          }
          
          // Comprobar si come comida
          const foodIndex = newState.food.findIndex(f => f.x === head.x && f.y === head.y);
          let hasEaten = false;
          
          if (foodIndex !== -1) {
            // Eliminar comida comida
            newState.food.splice(foodIndex, 1);
            
            // Añadir nueva comida en posición aleatoria
            const shrinkBorder = Math.floor(newState.mapSize * (1 - newState.shrinkFactor) / 2);
            const validX = shrinkBorder + Math.floor(Math.random() * (newState.mapSize - shrinkBorder * 2));
            const validY = shrinkBorder + Math.floor(Math.random() * (newState.mapSize - shrinkBorder * 2));
            
            newState.food.push({ x: validX, y: validY });
            
            // Aumentar puntuación y longitud
            newPlayer.score += 1;
            newPlayer.snake.length += 1;
            hasEaten = true;
          }
          
          // Mover cuerpo
          newPlayer.snake.body.unshift(head);
          
          // Si no ha comido, eliminar la cola
          if (!hasEaten && newPlayer.snake.body.length > newPlayer.snake.length) {
            newPlayer.snake.body.pop();
          }
          
          return newPlayer;
        });
        
        // Contar jugadores vivos
        const alivePlayers = newState.players.filter(p => p.isAlive);
        setPlayersLeft(alivePlayers.length);
        
        // Comprobar si el jugador actual ha muerto
        const currentPlayer = newState.players.find(p => p.id === playerId);
        if (currentPlayer && !currentPlayer.isAlive && playerRank === null) {
          // Calcular posición final
          const rank = newState.players.length - alivePlayers.length + 1;
          setPlayerRank(rank);
          
          // Actualizar estadísticas
          const stats = playerStatsStorage.getStorage();
          const updatedStats = { ...stats };
          updatedStats.gamesPlayed += 1;
          
          // Si es modo clásico y quedó en primer lugar
          if (newState.gameMode === 'classic' && rank === 1) {
            updatedStats.wins += 1;
            
            // Calcular premio (90% del total apostado)
            const totalPrize = room.entryFee * room.maxPlayers;
            
            // Calcular comisiones
            const systemCommissionRate = 0.1; // 10% de comisión total
            let influencerCommissionRate = 0;
            
            // Si es sala de influencer, dividir la comisión (6% sistema, 4% influencer)
            if (room.type === 'influencer' && room.creatorInfluencerId) {
              influencerCommissionRate = 0.04; // 4% para el influencer
            }
            
            const systemCommissionAmount = totalPrize * (systemCommissionRate - influencerCommissionRate);
            const winnerPrize = totalPrize - (totalPrize * systemCommissionRate);
            
            updatedStats.earnings += winnerPrize;
            
            // Actualizar balance
            const user = userStorage.getStorage();
            userStorage.setStorage({
              ...user,
              token: user.token + winnerPrize // Añadir a tokens, no directamente a USDT
            });
            
            // Actualizar comisión del sistema
            const systemCommission = systemCommissionStorage.getStorage();
            systemCommissionStorage.setStorage({
              ...systemCommission,
              totalCommission: systemCommission.totalCommission + systemCommissionAmount
            });
          }
          
          playerStatsStorage.setStorage(updatedStats);
        }
        
        // Comprobar si el juego ha terminado (modo clásico)
        if (newState.gameMode === 'classic' && alivePlayers.length <= 1) {
          setGameStatus('finished');
          
          // Si el jugador es el último vivo y aún no tiene rango
          if (alivePlayers.length === 1 && alivePlayers[0].id === playerId && playerRank === null) {
            setPlayerRank(1);
            
            // Actualizar estadísticas
            const stats = playerStatsStorage.getStorage();
            const updatedStats = { ...stats };
            updatedStats.gamesPlayed += 1;
            updatedStats.wins += 1;
            
            // Calcular premio (90% del total apostado)
            const totalPrize = room.entryFee * room.maxPlayers;
            
            // Calcular comisiones
            const systemCommissionRate = 0.1; // 10% de comisión total
            let influencerCommissionRate = 0;
            
            // Si es sala de influencer, dividir la comisión (6% sistema, 4% influencer)
            if (room.type === 'influencer' && room.creatorInfluencerId) {
              influencerCommissionRate = 0.04; // 4% para el influencer
            }
            
            const systemCommissionAmount = totalPrize * (systemCommissionRate - influencerCommissionRate);
            const winnerPrize = totalPrize - (totalPrize * systemCommissionRate);
            
            updatedStats.earnings += winnerPrize;
            
            // Actualizar balance
            const user = userStorage.getStorage();
            userStorage.setStorage({
              ...user,
              token: user.token + winnerPrize // Añadir a tokens, no directamente a USDT
            });
            
            // Actualizar comisión del sistema
            const systemCommission = systemCommissionStorage.getStorage();
            systemCommissionStorage.setStorage({
              ...systemCommission,
              totalCommission: systemCommission.totalCommission + systemCommissionAmount
            });
            
            playerStatsStorage.setStorage(updatedStats);
          }
        }
        
        // Encogimiento del mapa
        if (Date.now() >= newState.nextShrinkTime) {
          newState.shrinkFactor = Math.max(0.2, newState.shrinkFactor - 0.1);
          newState.nextShrinkTime = Date.now() + 60000; // Próximo encogimiento en 60 segundos
          
          // Añadir nuevos obstáculos en el borde
          const shrinkBorder = Math.floor(newState.mapSize * (1 - newState.shrinkFactor) / 2);
          
          for (let i = 0; i < newState.mapSize; i++) {
            // Bordes horizontales
            if (!newState.obstacles.some(o => o.x === i && o.y === shrinkBorder)) {
              newState.obstacles.push({ x: i, y: shrinkBorder });
            }
            if (!newState.obstacles.some(o => o.x === i && o.y === newState.mapSize - shrinkBorder - 1)) {
              newState.obstacles.push({ x: i, y: newState.mapSize - shrinkBorder - 1 });
            }
            
            // Bordes verticales
            if (!newState.obstacles.some(o => o.x === shrinkBorder && o.y === i)) {
              newState.obstacles.push({ x: shrinkBorder, y: i });
            }
            if (!newState.obstacles.some(o => o.x === newState.mapSize - shrinkBorder - 1 && o.y === i)) {
              newState.obstacles.push({ x: newState.mapSize - shrinkBorder - 1, y: i });
            }
          }
        }
        
        return newState;
      });
    }, 200); // Velocidad del juego
    
    return () => clearInterval(gameLoop);
  }, [gameStatus, gameState, playerId, playerRank, room]);
  
  // Manejar movimiento del jugador
  const handleMove = (direction) => {
    if (gameStatus !== 'playing') return;
    
    setGameState(prevState => {
      if (!prevState) return null;
      
      const newState = { ...prevState };
      const playerIndex = newState.players.findIndex(p => p.id === playerId);
      
      if (playerIndex === -1 || !newState.players[playerIndex].isAlive) return newState;
      
      // Evitar movimientos en dirección opuesta
      const currentDirection = newState.players[playerIndex].snake.direction;
      if (
        (direction === 'up' && currentDirection === 'down') ||
        (direction === 'down' && currentDirection === 'up') ||
        (direction === 'left' && currentDirection === 'right') ||
        (direction === 'right' && currentDirection === 'left')
      ) {
        return newState;
      }
      
      newState.players[playerIndex].snake.direction = direction;
      return newState;
    });
  };
  
  // Manejar retiro de ganancias
  const handleWithdraw = () => {
    setWithdrawing(true);
    
    // Simulación de procesamiento
    setTimeout(() => {
      const user = userStorage.getStorage();
      let winnings = 0;
      
      // Calcular ganancias según el modo de juego
      if (room.gameMode === 'classic') {
        // Modo clásico: el ganador se lleva todo (90%)
        winnings = room.entryFee * room.maxPlayers * 0.9;
      } else if (room.gameMode === 'survival') {
        // Modo supervivencia: se reparte entre los supervivientes
        const totalPrize = room.entryFee * room.maxPlayers;
        const systemCommission = totalPrize * 0.1; // 10% de comisión
        const prizePool = totalPrize - systemCommission;
        winnings = prizePool / survivors.length;
      }
      
      // Actualizar balance
      userStorage.setStorage({
        ...user,
        balance: user.balance + winnings,
        token: user.token - winnings
      });
      
      setWithdrawing(false);
      setShowWithdrawModal(false);
    }, 2000);
  };
  
  // Renderizar diferentes estados del juego
  const renderGameState = () => {
    if (gameStatus === 'waiting') {
      return (
        <div className="flex flex-col items-center justify-center h-96 bg-indigo-900/50 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-white mb-4">Esperando jugadores</h3>
          <p className="text-indigo-300 mb-6">
            {room.currentPlayers}/{room.maxPlayers} jugadores conectados
          </p>
          <div className="w-64 bg-indigo-800 rounded-full h-3 mb-6">
            <div 
              className="bg-gradient-to-r from-purple-500 to-indigo-500 h-3 rounded-full" 
              style={{ width: `${(room.currentPlayers / room.maxPlayers) * 100}%` }}
            ></div>
          </div>
          <p className="text-indigo-300 text-sm text-center">
            La partida comenzará cuando se conecten al menos {room.minPlayersToStart} jugadores.
            <br />
            {room.entryFee > 0 ? (
              <>
                Cada jugador ha apostado {room.entryFee} USDT.
                <br />
                Comisión del sistema: 10%
                {room.type === 'influencer' && (
                  <span> (4% para el influencer)</span>
                )}
              </>
            ) : (
              'Esta es una sala gratuita, ¡juega sin riesgo!'
            )}
          </p>
        </div>
      );
    }
    
    if (gameStatus === 'starting') {
      return (
        <div className="flex flex-col items-center justify-center h-96 bg-indigo-900/50 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-white mb-4">¡Preparándose para iniciar!</h3>
          <div className="text-6xl font-bold text-yellow-400 mb-6">{countdown}</div>
          <p className="text-indigo-300 text-sm text-center">
            Usa las flechas del teclado o los controles en pantalla para moverte.
            <br />
            {room.gameMode === 'classic' ? (
              'Sobrevive y elimina a otros jugadores para ganar.'
            ) : (
              `Sobrevive durante ${Math.floor(room.survivalTime / 60)} minutos para compartir el premio.`
            )}
          </p>
        </div>
      );
    }
    
    if (gameStatus === 'finished') {
      return (
        <div className="flex flex-col items-center justify-center h-96 bg-indigo-900/50 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-white mb-4">Partida finalizada</h3>
          
          {room.gameMode === 'classic' ? (
            // Resultado para modo clásico
            playerRank === 1 ? (
              <>
                <div className="text-6xl font-bold text-yellow-400 mb-6">¡VICTORIA!</div>
                {room.entryFee > 0 ? (
                  <>
                    <p className="text-green-400 text-xl font-bold mb-4">
                      +{Math.floor(room.entryFee * room.maxPlayers * 0.9)} SNK
                    </p>
                    <button
                      onClick={() => setShowWithdrawModal(true)}
                      className="mt-4 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg"
                    >
                      Retirar Ganancias
                    </button>
                  </>
                ) : (
                  <p className="text-indigo-300 mb-4">
                    ¡Felicidades por ganar la partida gratuita!
                  </p>
                )}
              </>
            ) : (
              <>
                <div className="text-4xl font-bold text-indigo-400 mb-6">
                  Posición #{playerRank}
                </div>
                <p className="text-indigo-300 mb-4">
                  Mejor suerte la próxima vez
                </p>
              </>
            )
          ) : (
            // Resultado para modo supervivencia
            survivors.some(p => p.id === playerId) ? (
              <>
                <div className="text-6xl font-bold text-yellow-400 mb-6">¡SOBREVIVISTE!</div>
                {room.entryFee > 0 ? (
                  <>
                    <p className="text-green-400 text-xl font-bold mb-4">
                      +{Math.floor((room.entryFee * room.maxPlayers * 0.9) / survivors.length)} SNK
                    </p>
                    <p className="text-indigo-300 mb-4">
                      Premio compartido entre {survivors.length} supervivientes
                    </p>
                    <button
                      onClick={() => setShowWithdrawModal(true)}
                      className="mt-4 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg"
                    >
                      Retirar Ganancias
                    </button>
                  </>
                ) : (
                  <p className="text-indigo-300 mb-4">
                    ¡Felicidades por sobrevivir en la partida gratuita!
                  </p>
                )}
              </>
            ) : (
              <>
                <div className="text-4xl font-bold text-indigo-400 mb-6">
                  No sobreviviste
                </div>
                <p className="text-indigo-300 mb-4">
                  Sobrevivieron {survivors.length} jugadores
                </p>
              </>
            )
          )}
          
          <button
            onClick={onExit}
            className="mt-4 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg"
          >
            Volver al lobby
          </button>
        </div>
      );
    }
    
    return (
      <div className="flex flex-col">
        <div className="bg-indigo-900/50 rounded-lg p-4 mb-4 flex justify-between items-center">
          <div>
            <p className="text-indigo-300 text-sm">Jugadores vivos</p>
            <p className="text-xl font-bold text-white">{playersLeft}</p>
          </div>
          
          {room.gameMode === 'survival' && survivalTimeRemaining !== null && (
            <div className="bg-blue-800/50 px-4 py-2 rounded-lg">
              <p className="text-indigo-300 text-sm">Tiempo restante</p>
              <p className="text-xl font-bold text-white">
                {Math.floor(survivalTimeRemaining / 60)}:
                {survivalTimeRemaining % 60 < 10 ? '0' : ''}
                {survivalTimeRemaining % 60}
              </p>
            </div>
          )}
          
          {playerRank && (
            <div className="bg-indigo-800 px-4 py-2 rounded-lg">
              <p className="text-indigo-300 text-sm">Tu posición</p>
              <p className="text-xl font-bold text-white">#{playerRank}</p>
            </div>
          )}
          
          <div>
            <p className="text-indigo-300 text-sm">Premio</p>
            <p className="text-xl font-bold text-yellow-400">
              {room.entryFee === 0 ? 
                '0 USDT' : 
                `${Math.floor(room.entryFee * room.maxPlayers * 0.9)} SNK`}
            </p>
            {room.entryFee > 0 && (
              <p className="text-xs text-gray-500 text-right">
                Comisión: 10%
              </p>
            )}
          </div>
        </div>
        
        <div className="h-96 bg-indigo-900/20 rounded-lg overflow-hidden">
          {gameState && (
            <GameCanvas 
              gameState={gameState} 
              playerId={playerId} 
              onMove={handleMove} 
            />
          )}
        </div>
        
        <GameControls onMove={handleMove} />
      </div>
    );
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <h2 className="text-2xl font-bold text-white mr-2">{room.name}</h2>
          {room.gameMode === 'survival' && (
            <span className="bg-blue-900 text-blue-300 text-xs px-2 py-1 rounded-full">
              Supervivencia
            </span>
          )}
        </div>
        
        {gameStatus !== 'playing' && (
          <button
            onClick={onExit}
            className="text-indigo-400 hover:text-white transition-colors flex items-center"
          >
            <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Salir
          </button>
        )}
      </div>
      
      {renderGameState()}
      
      {/* Modal de retiro de ganancias */}
      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-2xl p-6 max-w-md w-full">
            <h3 className="text-xl font-bold text-white mb-4">Retirar Ganancias</h3>
            
            <p className="text-indigo-300 mb-6">
              {room.gameMode === 'classic' ? (
                `¡Felicidades por tu victoria! Has ganado ${Math.floor(room.entryFee * room.maxPlayers * 0.9)} SNK.`
              ) : (
                `¡Felicidades por sobrevivir! Has ganado ${Math.floor((room.entryFee * room.maxPlayers * 0.9) / survivors.length)} SNK.`
              )}
              Puedes retirar tus ganancias ahora o mantenerlas en tu balance de tokens.
            </p>
            
            <div className="bg-indigo-800/50 rounded-lg p-4 mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-indigo-300">Ganancias</span>
                <span className="text-white font-medium">
                  {room.gameMode === 'classic' ? 
                    `${Math.floor(room.entryFee * room.maxPlayers * 0.9)} SNK` : 
                    `${Math.floor((room.entryFee * room.maxPlayers * 0.9) / survivors.length)} SNK`}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-indigo-300">Equivalente en USDT</span>
                <span className="text-white font-medium">
                  {room.gameMode === 'classic' ? 
                    `${Math.floor(room.entryFee * room.maxPlayers * 0.9)} USDT` : 
                    `${Math.floor((room.entryFee * room.maxPlayers * 0.9) / survivors.length)} USDT`}
                </span>
              </div>
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={() => setShowWithdrawModal(false)}
                className="flex-1 bg-indigo-800 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
              >
                Mantener Tokens
              </button>
              
              <button
                onClick={handleWithdraw}
                disabled={withdrawing}
                className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {withdrawing ? (
                  <div className="flex items-center justify-center">
                    <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Procesando...
                  </div>
                ) : (
                  'Retirar a USDT'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameRoom;