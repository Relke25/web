import React, { useState } from 'react';
import { userStorage } from '../utilities/storage';
import TokenExchange from './TokenExchange';
import ProfileStats from './ProfileStats';
import SnakeSkinSelector from './SnakeSkinSelector';
import snakeSkins from '../mock/snakeSkins';

const ProfilePage = ({ onNavigate }) => {
  const [showSkinSelector, setShowSkinSelector] = useState(false);
  const user = userStorage.getStorage();
  
  const handleDisconnect = () => {
    userStorage.setStorage({
      address: '',
      balance: 0,
      token: 0,
      isConnected: false,
      isInfluencer: false,
      influencerWallet: null,
      selectedSkin: 1,
      unlockedSkins: [1, 2, 3, 4, 5]
    });
    
    onNavigate('home');
  };
  
  // Obtener el skin seleccionado
  const selectedSkin = snakeSkins.find(skin => skin.id === user.selectedSkin) || snakeSkins[0];
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Mi Perfil</h2>
        <button
          onClick={() => onNavigate('home')}
          className="text-indigo-400 hover:text-white transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Volver
        </button>
      </div>
      
      <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-white mb-1">Wallet</h3>
            <p className="text-indigo-300 text-sm mb-4 break-all">{user.address}</p>
            
            <div className="flex space-x-6">
              <div>
                <p className="text-sm text-indigo-300">Balance USDT</p>
                <p className="text-2xl font-bold text-yellow-400">{user.balance.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm text-indigo-300">Tokens</p>
                <p className="text-2xl font-bold text-indigo-400">{user.token}</p>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end">
            {user.isInfluencer && (
              <div className="mb-4">
                <span className="bg-yellow-900 text-yellow-300 text-xs px-3 py-1 rounded-full">
                  Influencer
                </span>
              </div>
            )}
            <button
              onClick={handleDisconnect}
              className="bg-indigo-800 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Desconectar
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <TokenExchange />
          <ProfileStats />
        </div>
        
        <div>
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mb-6">
            <h3 className="text-xl font-bold text-white mb-4">Mi Serpiente</h3>
            
            <div className="bg-indigo-800/30 rounded-lg p-4 flex flex-col items-center mb-4">
              <h4 className="text-white font-medium mb-3">{selectedSkin.name}</h4>
              
              <div className="relative w-full h-32 bg-indigo-900/50 rounded-lg flex items-center justify-center mb-4">
                {/* Representación visual de la serpiente */}
                <div className="relative">
                  {/* Cuerpo de la serpiente */}
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <div 
                        key={i} 
                        className="w-8 h-8 rounded-sm m-0.5"
                        style={{ 
                          backgroundColor: selectedSkin.bodyColor,
                          boxShadow: selectedSkin.pattern === 'glow' ? `0 0 10px ${selectedSkin.bodyColor}` : 'none'
                        }}
                      ></div>
                    ))}
                  </div>
                  
                  {/* Cabeza de la serpiente */}
                  <div 
                    className="absolute -left-8 top-0 w-8 h-8 rounded-sm"
                    style={{ 
                      backgroundColor: selectedSkin.headColor,
                      boxShadow: selectedSkin.pattern === 'glow' ? `0 0 10px ${selectedSkin.headColor}` : 'none'
                    }}
                  >
                    {/* Ojos */}
                    <div className="absolute top-1 left-1 w-2 h-2 rounded-full" style={{ backgroundColor: selectedSkin.eyeColor }}></div>
                    <div className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ backgroundColor: selectedSkin.eyeColor }}></div>
                  </div>
                </div>
              </div>
              
              <div className="w-full">
                <div className="flex justify-between text-sm text-indigo-300 mb-1">
                  <span>Rareza:</span>
                  <span className={`
                    ${selectedSkin.rarity === 'common' ? 'text-gray-300' : ''}
                    ${selectedSkin.rarity === 'uncommon' ? 'text-green-400' : ''}
                    ${selectedSkin.rarity === 'rare' ? 'text-blue-400' : ''}
                    ${selectedSkin.rarity === 'epic' ? 'text-purple-400' : ''}
                    ${selectedSkin.rarity === 'legendary' ? 'text-yellow-400' : ''}
                  `}>
                    {selectedSkin.rarity.charAt(0).toUpperCase() + selectedSkin.rarity.slice(1)}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm text-indigo-300">
                  <span>Patrón:</span>
                  <span>{selectedSkin.pattern.charAt(0).toUpperCase() + selectedSkin.pattern.slice(1)}</span>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => setShowSkinSelector(true)}
              className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
            >
              Cambiar Skin
            </button>
          </div>
          
          {user.isInfluencer ? (
            <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Panel de Influencer</h3>
              
              <div className="bg-indigo-800/30 rounded-lg p-4 mb-4">
                <p className="text-indigo-300 mb-2">
                  Como influencer, puedes crear salas privadas y ganar comisiones por cada partida.
                </p>
                <p className="text-indigo-300">
                  Recibirás el 4% de todas las apuestas realizadas en tus salas.
                </p>
              </div>
              
              <button
                onClick={() => onNavigate('influencer')}
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
              >
                Ir al Panel de Influencer
              </button>
            </div>
          ) : (
            <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">Programa de Influencers</h3>
              
              <div className="bg-indigo-800/30 rounded-lg p-4 mb-4">
                <p className="text-indigo-300 mb-2">
                  Conviértete en influencer y gana comisiones del 4% por cada partida en tus salas personalizadas.
                </p>
                <p className="text-indigo-300">
                  Crea tus propias salas y compártelas con tus seguidores.
                </p>
              </div>
              
              <button
                onClick={() => onNavigate('becomeInfluencer')}
                className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
              >
                Solicitar ser Influencer
              </button>
            </div>
          )}
        </div>
      </div>
      
      {showSkinSelector && (
        <SnakeSkinSelector onClose={() => setShowSkinSelector(false)} />
      )}
    </div>
  );
};

export default ProfilePage;