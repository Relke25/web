import React from 'react';
import RoomCard from './RoomCard';

const RoomsList = ({ rooms, onJoinRoom }) => {
  // Agrupar salas por tipo
  const standardRooms = rooms.filter(room => room.type === 'standard' || room.type === 'free');
  const privateRooms = rooms.filter(room => room.type === 'private' || room.type === 'influencer');
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold text-white mb-6">Salas disponibles</h2>
      
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-indigo-300 mb-4">Salas públicas</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {standardRooms.map(room => (
            <RoomCard 
              key={room.id} 
              room={room} 
              onJoin={onJoinRoom} 
            />
          ))}
        </div>
      </div>
      
      {privateRooms.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-indigo-300 mb-4">Salas privadas</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {privateRooms.map(room => (
              <RoomCard 
                key={room.id} 
                room={room} 
                onJoin={onJoinRoom} 
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default RoomsList;