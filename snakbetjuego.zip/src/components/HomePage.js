import React, { useState, useEffect } from 'react';
import RoomsList from './RoomsList';
import TokenExchange from './TokenExchange';
import gameRooms from '../mock/gameRooms';
import { userStorage, currentRoomStorage, privateRoomsStorage, systemCommissionStorage } from '../utilities/storage';

const HomePage = ({ onNavigate }) => {
  const [rooms, setRooms] = useState([]);
  const [activeTab, setActiveTab] = useState('all'); // 'all', 'classic', 'survival', 'free'
  const user = userStorage.getStorage();
  
  // Cargar salas
  useEffect(() => {
    // Combinar salas estándar con salas privadas
    const privateRooms = privateRoomsStorage.getStorage();
    setRooms([...gameRooms, ...privateRooms]);
  }, []);
  
  // Filtrar salas según la pestaña activa
  const filteredRooms = rooms.filter(room => {
    if (activeTab === 'all') return true;
    if (activeTab === 'classic') return room.gameMode === 'classic' && room.entryFee > 0;
    if (activeTab === 'survival') return room.gameMode === 'survival';
    if (activeTab === 'free') return room.entryFee === 0;
    return true;
  });
  
  const handleJoinRoom = (room) => {
    if (!user.isConnected) {
      onNavigate('connect');
      return;
    }
    
    // Si es sala gratuita, no verificar saldo
    if (room.entryFee > 0) {
      // Verificar si el usuario tiene suficiente saldo
      if (user.balance < room.entryFee) {
        alert(`No tienes suficiente saldo. Necesitas ${room.entryFee} USDT para unirte a esta sala.`);
        return;
      }
      
      // Descontar el costo de entrada
      const updatedUser = { ...user };
      updatedUser.balance -= room.entryFee;
      userStorage.setStorage(updatedUser);
      
      // Actualizar comisión del sistema (10% de la apuesta)
      const systemCommission = systemCommissionStorage.getStorage();
      const commission = room.entryFee * 0.1;
      
      // Si es sala de influencer, dividir la comisión (6% sistema, 4% influencer)
      if (room.type === 'influencer' && room.creatorInfluencerId) {
        // Aquí se procesaría la comisión del influencer (simulado)
        console.log(`Comisión para influencer: ${room.entryFee * 0.04} USDT`);
      }
      
      systemCommissionStorage.setStorage({
        ...systemCommission,
        totalCommission: systemCommission.totalCommission + commission
      });
    }
    
    // Guardar la sala actual
    currentRoomStorage.setStorage(room);
    
    // Navegar a la sala
    onNavigate('game');
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="bg-gradient-to-r from-indigo-900 to-purple-900 rounded-xl shadow-xl overflow-hidden">
          <div className="md:flex">
            <div className="md:w-2/3 p-8">
              <h1 className="text-4xl font-bold text-white mb-4">
                ¡Compite y gana <span className="text-yellow-400">USDT</span>!
              </h1>
              <p className="text-indigo-300 mb-6">
                Únete a la batalla de serpientes más emocionante. Elimina a tus oponentes, 
                sobrevive a los obstáculos y llévate el premio.
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="bg-indigo-800/50 rounded-lg p-4 flex-1">
                  <p className="text-indigo-300 text-sm">Jugadores online</p>
                  <p className="text-2xl font-bold text-white">1,458</p>
                </div>
                <div className="bg-indigo-800/50 rounded-lg p-4 flex-1">
                  <p className="text-indigo-300 text-sm">Partidas hoy</p>
                  <p className="text-2xl font-bold text-white">247</p>
                </div>
                <div className="bg-indigo-800/50 rounded-lg p-4 flex-1">
                  <p className="text-indigo-300 text-sm">Premio más grande</p>
                  <p className="text-2xl font-bold text-yellow-400">1,000 USDT</p>
                </div>
              </div>
            </div>
            <div className="md:w-1/3 bg-gradient-to-br from-indigo-800 to-purple-800 p-6 flex flex-col justify-center">
              {user.isConnected ? (
                <div>
                  <h3 className="text-xl font-bold text-white mb-4">¡Bienvenido de nuevo!</h3>
                  <p className="text-indigo-300 mb-4">
                    Tu balance actual es de <span className="text-yellow-400 font-bold">{user.balance.toFixed(2)} USDT</span>
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onNavigate('profile')}
                      className="bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                    >
                      Mi Perfil
                    </button>
                    <button
                      onClick={() => onNavigate('createRoom')}
                      className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-2 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
                    >
                      Crear Sala
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <h3 className="text-xl font-bold text-white mb-4">¡Únete ahora!</h3>
                  <p className="text-indigo-300 mb-4">
                    Conecta tu wallet para empezar a jugar y ganar USDT
                  </p>
                  <button
                    onClick={() => onNavigate('connect')}
                    className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
                  >
                    Conectar Wallet
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Pestañas de filtrado */}
      <div className="flex mb-6 border-b border-indigo-800">
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'all' 
              ? 'text-white border-b-2 border-yellow-400' 
              : 'text-indigo-300 hover:text-white'
          }`}
          onClick={() => setActiveTab('all')}
        >
          Todas las salas
        </button>
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'classic' 
              ? 'text-white border-b-2 border-yellow-400' 
              : 'text-indigo-300 hover:text-white'
          }`}
          onClick={() => setActiveTab('classic')}
        >
          Modo Clásico
        </button>
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'survival' 
              ? 'text-white border-b-2 border-yellow-400' 
              : 'text-indigo-300 hover:text-white'
          }`}
          onClick={() => setActiveTab('survival')}
        >
          Supervivencia
        </button>
        <button
          className={`py-3 px-6 font-medium transition-colors ${
            activeTab === 'free' 
              ? 'text-white border-b-2 border-yellow-400' 
              : 'text-indigo-300 hover:text-white'
          }`}
          onClick={() => setActiveTab('free')}
        >
          Salas Gratuitas
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <RoomsList rooms={filteredRooms} onJoinRoom={handleJoinRoom} />
        </div>
        
        <div className="lg:col-span-1">
          {user.isConnected && <TokenExchange />}
          
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mt-6">
            <h3 className="text-xl font-bold text-white mb-4">Modos de Juego</h3>
            
            <div className="space-y-4">
              <div className="bg-indigo-800/30 rounded-lg p-4">
                <h4 className="font-medium text-white mb-2">Modo Clásico</h4>
                <p className="text-sm text-indigo-300">
                  Elimina a todos los demás jugadores y sé el último en sobrevivir para ganar todo el premio.
                </p>
              </div>
              
              <div className="bg-indigo-800/30 rounded-lg p-4">
                <h4 className="font-medium text-white mb-2">Modo Supervivencia</h4>
                <p className="text-sm text-indigo-300">
                  Sobrevive durante 5 minutos y comparte el premio con los demás supervivientes.
                </p>
              </div>
              
              <div className="bg-indigo-800/30 rounded-lg p-4">
                <h4 className="font-medium text-white mb-2">Salas Gratuitas</h4>
                <p className="text-sm text-indigo-300">
                  Practica sin arriesgar USDT. Estas salas comienzan con solo 2 jugadores.
                </p>
              </div>
              
              <div className="bg-indigo-800/30 rounded-lg p-4">
                <h4 className="font-medium text-white mb-2">Salas Privadas</h4>
                <p className="text-sm text-indigo-300">
                  Crea tu propia sala con reglas personalizadas e invita a tus amigos con un ID único.
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mt-6">
            <h3 className="text-xl font-bold text-white mb-4">Acciones Rápidas</h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onNavigate('createRoom')}
                className="bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-2 px-4 rounded-lg transition-colors text-sm"
              >
                Crear Sala
              </button>
              <button
                onClick={() => onNavigate('joinPrivate')}
                className="bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-2 px-4 rounded-lg transition-colors text-sm"
              >
                Unirse con ID
              </button>
              <button
                onClick={() => onNavigate('exchange')}
                className="bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-2 px-4 rounded-lg transition-colors text-sm"
              >
                Intercambio
              </button>
              <button
                onClick={() => onNavigate('profile')}
                className="bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-2 px-4 rounded-lg transition-colors text-sm"
              >
                Mi Perfil
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;