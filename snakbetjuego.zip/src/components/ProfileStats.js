import React from 'react';
import { playerStatsStorage } from '../utilities/storage';

const ProfileStats = () => {
  const stats = playerStatsStorage.getStorage();
  
  const statItems = [
    {
      name: 'Partidas jugadas',
      value: stats.gamesPlayed,
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/>
          <path d="M15 8h-2v4h-4V8H7v8h2v-2h6v2h2V8z" fill="currentColor"/>
        </svg>
      )
    },
    {
      name: 'Victorias',
      value: stats.wins,
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zm-2 3V7h2v1c0 1.65-1.35 3-3 3h-.38c.4-.58.65-1.27.69-2H17zM7 8V7h2v2H7.69c.04.73.29 1.42.69 2H8c-1.65 0-3-1.35-3-3V7h2v1z" fill="currentColor"/>
        </svg>
      )
    },
    {
      name: 'Eliminaciones',
      value: stats.kills,
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8 0-1.85.63-3.55 1.69-4.9L16.9 18.31C15.55 19.37 13.85 20 12 20zm6.31-3.1L7.1 5.69C8.45 4.63 10.15 4 12 4c4.42 0 8 3.58 8 8 0 1.85-.63 3.55-1.69 4.9z" fill="currentColor"/>
        </svg>
      )
    },
    {
      name: 'Ganancias',
      value: `${stats.earnings.toFixed(2)} USDT`,
      icon: (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z" fill="currentColor"/>
        </svg>
      )
    }
  ];
  
  return (
    <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
      <h3 className="text-xl font-bold text-white mb-4">Estadísticas de juego</h3>
      
      <div className="grid grid-cols-2 gap-4">
        {statItems.map((item, index) => (
          <div key={index} className="bg-indigo-800/50 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <div className="text-indigo-400 mr-2">
                {item.icon}
              </div>
              <span className="text-sm text-indigo-300">{item.name}</span>
            </div>
            <div className="text-xl font-bold text-white">{item.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProfileStats;