import React, { useState, useEffect } from 'react';
import { userStorage } from '../utilities/storage';
import snakeSkins from '../mock/snakeSkins';

const SnakeSkinSelector = ({ onClose }) => {
  const [selectedSkinId, setSelectedSkinId] = useState(1);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const skinsPerPage = 12;
  
  const user = userStorage.getStorage();
  
  // Inicializar con el skin actual del usuario
  useEffect(() => {
    setSelectedSkinId(user.selectedSkin || 1);
  }, []);
  
  // Filtrar skins
  const filteredSkins = snakeSkins.filter(skin => {
    // Filtro por término de búsqueda
    const matchesSearch = skin.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filtro por categoría
    if (filter === 'all') return matchesSearch;
    if (filter === 'unlocked') return matchesSearch && user.unlockedSkins.includes(skin.id);
    if (filter === 'locked') return matchesSearch && !user.unlockedSkins.includes(skin.id);
    
    // Filtro por rareza
    return matchesSearch && skin.rarity === filter;
  });
  
  // Paginación
  const indexOfLastSkin = currentPage * skinsPerPage;
  const indexOfFirstSkin = indexOfLastSkin - skinsPerPage;
  const currentSkins = filteredSkins.slice(indexOfFirstSkin, indexOfLastSkin);
  const totalPages = Math.ceil(filteredSkins.length / skinsPerPage);
  
  // Cambiar de página
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  
  // Seleccionar skin
  const handleSelectSkin = (skinId) => {
    // Verificar si el skin está desbloqueado
    if (user.unlockedSkins.includes(skinId)) {
      setSelectedSkinId(skinId);
    } else {
      // Mostrar mensaje de que el skin está bloqueado
      alert('Este skin está bloqueado. Desbloquéalo para usarlo.');
    }
  };
  
  // Guardar selección
  const handleSave = () => {
    const updatedUser = { ...user, selectedSkin: selectedSkinId };
    userStorage.setStorage(updatedUser);
    onClose();
  };
  
  // Obtener skin por ID
  const getSelectedSkin = () => {
    return snakeSkins.find(skin => skin.id === selectedSkinId) || snakeSkins[0];
  };
  
  // Renderizar vista previa del skin
  const renderSkinPreview = () => {
    const skin = getSelectedSkin();
    
    return (
      <div className="bg-indigo-800/30 rounded-lg p-4 flex flex-col items-center">
        <h4 className="text-white font-medium mb-3">{skin.name}</h4>
        
        <div className="relative w-48 h-48 bg-indigo-900/50 rounded-lg flex items-center justify-center mb-4">
          {/* Representación visual de la serpiente */}
          <div className="relative">
            {/* Cuerpo de la serpiente */}
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <div 
                  key={i} 
                  className="w-8 h-8 rounded-sm m-0.5"
                  style={{ 
                    backgroundColor: skin.bodyColor,
                    boxShadow: skin.pattern === 'glow' ? `0 0 10px ${skin.bodyColor}` : 'none'
                  }}
                ></div>
              ))}
            </div>
            
            {/* Cabeza de la serpiente */}
            <div 
              className="absolute -left-8 top-0 w-8 h-8 rounded-sm"
              style={{ 
                backgroundColor: skin.headColor,
                boxShadow: skin.pattern === 'glow' ? `0 0 10px ${skin.headColor}` : 'none'
              }}
            >
              {/* Ojos */}
              <div className="absolute top-1 left-1 w-2 h-2 rounded-full" style={{ backgroundColor: skin.eyeColor }}></div>
              <div className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ backgroundColor: skin.eyeColor }}></div>
            </div>
          </div>
        </div>
        
        <div className="w-full">
          <div className="flex justify-between text-sm text-indigo-300 mb-1">
            <span>Rareza:</span>
            <span className={`
              ${skin.rarity === 'common' ? 'text-gray-300' : ''}
              ${skin.rarity === 'uncommon' ? 'text-green-400' : ''}
              ${skin.rarity === 'rare' ? 'text-blue-400' : ''}
              ${skin.rarity === 'epic' ? 'text-purple-400' : ''}
              ${skin.rarity === 'legendary' ? 'text-yellow-400' : ''}
            `}>
              {skin.rarity.charAt(0).toUpperCase() + skin.rarity.slice(1)}
            </span>
          </div>
          
          <div className="flex justify-between text-sm text-indigo-300 mb-1">
            <span>Patrón:</span>
            <span>{skin.pattern.charAt(0).toUpperCase() + skin.pattern.slice(1)}</span>
          </div>
          
          <div className="flex justify-between text-sm text-indigo-300">
            <span>Estado:</span>
            <span className={user.unlockedSkins.includes(skin.id) ? 'text-green-400' : 'text-red-400'}>
              {user.unlockedSkins.includes(skin.id) ? 'Desbloqueado' : 'Bloqueado'}
            </span>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-white">Seleccionar Skin</h3>
          <button 
            onClick={onClose}
            className="text-indigo-300 hover:text-white"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            {renderSkinPreview()}
            
            <div className="mt-4 space-y-2">
              <button
                onClick={handleSave}
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
              >
                Guardar Selección
              </button>
              
              <button
                onClick={onClose}
                className="w-full bg-indigo-800 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <div className="mb-4 flex flex-col sm:flex-row gap-2">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Buscar skin..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="bg-indigo-800 border border-indigo-700 rounded-lg py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">Todos</option>
                <option value="unlocked">Desbloqueados</option>
                <option value="locked">Bloqueados</option>
                <option value="common">Común</option>
                <option value="uncommon">Poco común</option>
                <option value="rare">Raro</option>
                <option value="epic">Épico</option>
                <option value="legendary">Legendario</option>
              </select>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {currentSkins.map(skin => (
                <div 
                  key={skin.id}
                  onClick={() => handleSelectSkin(skin.id)}
                  className={`
                    bg-indigo-800/30 rounded-lg p-2 cursor-pointer transition-all
                    ${selectedSkinId === skin.id ? 'ring-2 ring-yellow-400' : 'hover:bg-indigo-800/50'}
                    ${!user.unlockedSkins.includes(skin.id) ? 'opacity-60' : ''}
                  `}
                >
                  <div 
                    className="w-full h-16 rounded-md mb-2 flex items-center justify-center"
                    style={{ 
                      backgroundColor: skin.pattern === 'gradient' ? 'transparent' : skin.bodyColor,
                      background: skin.pattern === 'gradient' ? `linear-gradient(45deg, ${skin.headColor}, ${skin.bodyColor})` : '',
                      boxShadow: skin.pattern === 'glow' ? `0 0 10px ${skin.bodyColor}` : 'none'
                    }}
                  >
                    {/* Representación simple de la serpiente */}
                    <div 
                      className="w-6 h-6 rounded-sm"
                      style={{ backgroundColor: skin.headColor }}
                    ></div>
                  </div>
                  
                  <div className="text-center">
                    <p className="text-white text-sm font-medium truncate">{skin.name}</p>
                    <p className={`text-xs
                      ${skin.rarity === 'common' ? 'text-gray-300' : ''}
                      ${skin.rarity === 'uncommon' ? 'text-green-400' : ''}
                      ${skin.rarity === 'rare' ? 'text-blue-400' : ''}
                      ${skin.rarity === 'epic' ? 'text-purple-400' : ''}
                      ${skin.rarity === 'legendary' ? 'text-yellow-400' : ''}
                    `}>
                      {skin.rarity.charAt(0).toUpperCase() + skin.rarity.slice(1)}
                    </p>
                  </div>
                  
                  {!user.unlockedSkins.includes(skin.id) && (
                    <div className="absolute inset-0 flex items-center justify-center rounded-lg">
                      <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                      </svg>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            {/* Paginación */}
            {totalPages > 1 && (
              <div className="flex justify-center mt-6">
                <nav className="flex space-x-1">
                  <button
                    onClick={() => paginate(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1 rounded-md bg-indigo-800 text-white disabled:opacity-50"
                  >
                    &laquo;
                  </button>
                  
                  {[...Array(totalPages)].map((_, i) => (
                    <button
                      key={i}
                      onClick={() => paginate(i + 1)}
                      className={`px-3 py-1 rounded-md ${
                        currentPage === i + 1
                          ? 'bg-indigo-600 text-white'
                          : 'bg-indigo-800 text-indigo-300 hover:bg-indigo-700'
                      }`}
                    >
                      {i + 1}
                    </button>
                  ))}
                  
                  <button
                    onClick={() => paginate(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 rounded-md bg-indigo-800 text-white disabled:opacity-50"
                  >
                    &raquo;
                  </button>
                </nav>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SnakeSkinSelector;