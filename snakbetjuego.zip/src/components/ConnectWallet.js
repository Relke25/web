import React, { useState } from 'react';
import { userStorage } from '../utilities/storage';

const ConnectWallet = ({ onConnect }) => {
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState('');
  const [isInfluencer, setIsInfluencer] = useState(false);
  const [influencerWallet, setInfluencerWallet] = useState('');
  
  const handleConnect = async () => {
    setConnecting(true);
    setError('');
    
    try {
      // Simulación de conexión a wallet
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simular dirección de wallet
      const mockAddress = '0x' + Math.random().toString(16).substr(2, 40);
      
      // Guardar datos del usuario
      userStorage.setStorage({
        address: mockAddress,
        balance: 100, // Balance inicial simulado
        token: 0,
        isConnected: true,
        isInfluencer: isInfluencer,
        influencerWallet: isInfluencer ? influencerWallet : null
      });
      
      onConnect();
    } catch (err) {
      setError('Error al conectar wallet. Inténtalo de nuevo.');
    } finally {
      setConnecting(false);
    }
  };
  
  return (
    <div className="flex flex-col items-center justify-center p-8 max-w-md mx-auto">
      <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-2xl shadow-2xl p-8 w-full">
        <h2 className="text-2xl font-bold text-white mb-6 text-center">Conecta tu Wallet</h2>
        
        <div className="space-y-4">
          <button
            onClick={handleConnect}
            disabled={connecting}
            className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center"
          >
            {connecting ? (
              <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <svg className="w-6 h-6 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 5H5C3.89543 5 3 5.89543 3 7V17C3 18.1046 3.89543 19 5 19H19C20.1046 19 21 18.1046 21 17V7C21 5.89543 20.1046 5 19 5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M3 7L12 13L21 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
            {connecting ? 'Conectando...' : 'Conectar Wallet'}
          </button>
          
          <div className="flex items-center justify-center">
            <div className="border-t border-indigo-800 flex-grow"></div>
            <div className="mx-4 text-sm text-indigo-300">o</div>
            <div className="border-t border-indigo-800 flex-grow"></div>
          </div>
          
          <button
            className="w-full bg-indigo-800 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-xl transition-all flex items-center justify-center"
          >
            <svg className="w-6 h-6 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286z" fill="currentColor"/>
            </svg>
            Unirse con Discord
          </button>
        </div>
        
        <div className="mt-6 border-t border-indigo-800 pt-6">
          <div className="flex items-center mb-4">
            <input
              id="influencer-checkbox"
              type="checkbox"
              checked={isInfluencer}
              onChange={() => setIsInfluencer(!isInfluencer)}
              className="w-4 h-4 text-indigo-600 bg-indigo-800 border-indigo-700 rounded focus:ring-indigo-500"
            />
            <label htmlFor="influencer-checkbox" className="ml-2 text-sm text-indigo-300">
              Soy influencer y quiero crear salas personalizadas
            </label>
          </div>
          
          {isInfluencer && (
            <div className="mb-4">
              <label className="block text-sm text-indigo-300 mb-2">
                Dirección de wallet para comisiones
              </label>
              <input
                type="text"
                value={influencerWallet}
                onChange={(e) => setInfluencerWallet(e.target.value)}
                placeholder="0x..."
                className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <p className="mt-1 text-xs text-indigo-400">
                Recibirás el 4% de comisión por cada partida en tus salas privadas
              </p>
            </div>
          )}
        </div>
        
        {error && (
          <div className="mt-4 text-red-400 text-sm text-center">
            {error}
          </div>
        )}
        
        <div className="mt-6 text-xs text-indigo-300 text-center">
          <p>Al conectar tu wallet, aceptas nuestros</p>
          <p>
            <a href="#" className="text-yellow-400 hover:text-yellow-300">Términos de Servicio</a>
            {' y '}
            <a href="#" className="text-yellow-400 hover:text-yellow-300">Política de Privacidad</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ConnectWallet;