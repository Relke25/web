import React, { useState } from 'react';
import { privateRoomsStorage } from '../utilities/storage';

const JoinPrivateForm = ({ onJoinRoom, onCancel }) => {
  const [roomId, setRoomId] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState('');
  
  const handleJoinRoom = () => {
    if (!roomId.trim()) {
      setError('Por favor, ingresa el ID de la sala');
      return;
    }
    
    setIsSearching(true);
    setError('');
    
    // Simulación de búsqueda
    setTimeout(() => {
      const privateRooms = privateRoomsStorage.getStorage();
      const room = privateRooms.find(r => r.roomId.toLowerCase() === roomId.toLowerCase());
      
      if (room) {
        onJoinRoom(room);
      } else {
        setError('No se encontró ninguna sala con ese ID');
        setIsSearching(false);
      }
    }, 1000);
  };
  
  return (
    <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
      <h3 className="text-xl font-bold text-white mb-6">Unirse a Sala Privada</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-indigo-300 mb-2">
            ID de la sala
          </label>
          <input
            type="text"
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
            placeholder="Ej: ABC123"
            className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase"
          />
          <p className="mt-1 text-xs text-indigo-400">
            Ingresa el ID proporcionado por el creador de la sala
          </p>
        </div>
        
        {error && (
          <div className="p-3 bg-red-900/50 text-red-300 rounded-lg text-sm">
            {error}
          </div>
        )}
        
        <div className="flex space-x-4 pt-4">
          <button
            onClick={onCancel}
            className="flex-1 bg-indigo-800 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          
          <button
            onClick={handleJoinRoom}
            disabled={isSearching}
            className="flex-1 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isSearching ? (
              <div className="flex items-center justify-center">
                <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Buscando...
              </div>
            ) : (
              'Unirse a la Sala'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default JoinPrivateForm;