import React, { useState } from 'react';
import { userStorage, tokenTransactionsStorage } from '../utilities/storage';
import gameTokens from '../mock/gameTokens';

const TokenExchangePage = ({ onNavigate }) => {
  const [exchangeAmount, setExchangeAmount] = useState(1);
  const [exchangeType, setExchangeType] = useState('buy'); // 'buy' or 'sell'
  const [isProcessing, setIsProcessing] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  const [withdrawAmount, setWithdrawAmount] = useState(0);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawMessage, setWithdrawMessage] = useState({ text: '', type: '' });
  
  const user = userStorage.getStorage();
  
  const handleExchange = () => {
    setIsProcessing(true);
    setMessage({ text: '', type: '' });
    
    // Simulación de procesamiento
    setTimeout(() => {
      const updatedUser = { ...user };
      
      if (exchangeType === 'buy') {
        // Comprar tokens con USDT
        if (user.balance < exchangeAmount) {
          setMessage({ 
            text: 'Saldo USDT insuficiente para realizar el intercambio', 
            type: 'error' 
          });
          setIsProcessing(false);
          return;
        }
        
        updatedUser.balance -= exchangeAmount;
        updatedUser.token += exchangeAmount * gameTokens.exchangeRate;
        
        // Registrar transacción
        const transactions = tokenTransactionsStorage.getStorage();
        tokenTransactionsStorage.setStorage([
          ...transactions,
          {
            id: Date.now(),
            type: 'buy',
            amount: exchangeAmount,
            tokens: exchangeAmount * gameTokens.exchangeRate,
            timestamp: new Date().toISOString(),
            status: 'completed',
            userId: user.address
          }
        ]);
        
        setMessage({ 
          text: `Has comprado ${exchangeAmount * gameTokens.exchangeRate} SNK exitosamente`, 
          type: 'success' 
        });
      } else {
        // Vender tokens por USDT
        if (user.token < exchangeAmount) {
          setMessage({ 
            text: 'No tienes suficientes tokens para vender', 
            type: 'error' 
          });
          setIsProcessing(false);
          return;
        }
        
        updatedUser.token -= exchangeAmount;
        updatedUser.balance += exchangeAmount / gameTokens.exchangeRate;
        
        // Registrar transacción
        const transactions = tokenTransactionsStorage.getStorage();
        tokenTransactionsStorage.setStorage([
          ...transactions,
          {
            id: Date.now(),
            type: 'sell',
            amount: exchangeAmount / gameTokens.exchangeRate,
            tokens: exchangeAmount,
            timestamp: new Date().toISOString(),
            status: 'completed',
            userId: user.address
          }
        ]);
        
        setMessage({ 
          text: `Has vendido ${exchangeAmount} SNK por ${exchangeAmount / gameTokens.exchangeRate} USDT`, 
          type: 'success' 
        });
      }
      
      userStorage.setStorage(updatedUser);
      setIsProcessing(false);
    }, 1500);
  };
  
  const handleWithdraw = () => {
    if (withdrawAmount <= 0) {
      setWithdrawMessage({
        text: 'Ingresa una cantidad válida para retirar',
        type: 'error'
      });
      return;
    }
    
    if (withdrawAmount > user.balance) {
      setWithdrawMessage({
        text: 'No tienes suficiente saldo USDT para retirar',
        type: 'error'
      });
      return;
    }
    
    setIsWithdrawing(true);
    setWithdrawMessage({ text: '', type: '' });
    
    // Simulación de procesamiento de retiro
    setTimeout(() => {
      const updatedUser = { ...user };
      updatedUser.balance -= withdrawAmount;
      
      // Añadir a retiros pendientes (simulado)
      updatedUser.pendingWithdrawals = [
        ...(updatedUser.pendingWithdrawals || []),
        {
          id: Date.now(),
          amount: withdrawAmount,
          timestamp: new Date().toISOString(),
          status: 'processing',
          txHash: '0x' + Math.random().toString(36).substr(2, 32)
        }
      ];
      
      userStorage.setStorage(updatedUser);
      
      setWithdrawMessage({
        text: `Retiro de ${withdrawAmount} USDT iniciado. Se procesará en breve.`,
        type: 'success'
      });
      
      setWithdrawAmount(0);
      setIsWithdrawing(false);
    }, 2000);
  };
  
  // Obtener transacciones del usuario
  const transactions = tokenTransactionsStorage.getStorage().filter(
    tx => tx.userId === user.address
  ).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 5);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Intercambio de Tokens</h2>
        <button
          onClick={() => onNavigate('home')}
          className="text-indigo-400 hover:text-white transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Volver
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mb-6">
            <h3 className="text-xl font-bold text-white mb-4">Información del Token</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-indigo-800/50 rounded-lg p-4">
                <p className="text-sm text-indigo-300">Nombre</p>
                <p className="text-xl font-bold text-white">{gameTokens.name} ({gameTokens.symbol})</p>
              </div>
              <div className="bg-indigo-800/50 rounded-lg p-4">
                <p className="text-sm text-indigo-300">Tasa de cambio</p>
                <p className="text-xl font-bold text-white">1 USDT = {gameTokens.exchangeRate} SNK</p>
              </div>
              <div className="bg-indigo-800/50 rounded-lg p-4">
                <p className="text-sm text-indigo-300">Suministro circulante</p>
                <p className="text-xl font-bold text-white">{gameTokens.circulatingSupply.toLocaleString()} SNK</p>
              </div>
            </div>
            
            <div className="bg-indigo-800/30 rounded-lg p-4 mb-6">
              <p className="text-indigo-300">
                SnakeCoin (SNK) es el token interno de SnakeBet. Puedes intercambiar USDT por SNK y viceversa en cualquier momento. 
                Todas las ganancias de las partidas se pueden retirar automáticamente a tu wallet.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-white mb-4">Intercambiar Tokens</h4>
                
                <div className="mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-indigo-300">Tipo de intercambio</span>
                  </div>
                  <div className="flex bg-indigo-800 rounded-lg p-1">
                    <button
                      className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                        exchangeType === 'buy' 
                          ? 'bg-indigo-600 text-white' 
                          : 'text-indigo-300 hover:text-white'
                      }`}
                      onClick={() => setExchangeType('buy')}
                    >
                      Comprar SNK
                    </button>
                    <button
                      className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                        exchangeType === 'sell' 
                          ? 'bg-indigo-600 text-white' 
                          : 'text-indigo-300 hover:text-white'
                      }`}
                      onClick={() => setExchangeType('sell')}
                    >
                      Vender SNK
                    </button>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-indigo-300">Cantidad</span>
                    <span className="text-sm text-indigo-300">
                      {exchangeType === 'buy' 
                        ? `Balance: ${user.balance.toFixed(2)} USDT` 
                        : `Tokens: ${user.token} SNK`}
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      min="1"
                      value={exchangeAmount}
                      onChange={(e) => setExchangeAmount(Math.max(1, parseFloat(e.target.value) || 0))}
                      className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <span className="text-indigo-400">
                        {exchangeType === 'buy' ? 'USDT' : 'SNK'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-indigo-800/50 rounded-lg p-4 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-indigo-300">Recibirás</span>
                    <span className="text-white font-medium">
                      {exchangeType === 'buy' 
                        ? `${exchangeAmount * gameTokens.exchangeRate} SNK` 
                        : `${(exchangeAmount / gameTokens.exchangeRate).toFixed(2)} USDT`}
                    </span>
                  </div>
                </div>
                
                {message.text && (
                  <div className={`mb-4 p-3 rounded-lg text-sm ${
                    message.type === 'error' ? 'bg-red-900/50 text-red-300' : 'bg-green-900/50 text-green-300'
                  }`}>
                    {message.text}
                  </div>
                )}
                
                <button
                  onClick={handleExchange}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isProcessing ? (
                    <div className="flex items-center justify-center">
                      <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Procesando...
                    </div>
                  ) : (
                    exchangeType === 'buy' ? 'Comprar SNK' : 'Vender SNK'
                  )}
                </button>
              </div>
              
              <div>
                <h4 className="text-lg font-semibold text-white mb-4">Retirar USDT</h4>
                
                <div className="mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-indigo-300">Cantidad a retirar</span>
                    <span className="text-sm text-indigo-300">
                      Balance: {user.balance.toFixed(2)} USDT
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <span className="text-indigo-400">USDT</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-indigo-800/50 rounded-lg p-4 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-indigo-300">Dirección de wallet</span>
                  </div>
                  <div className="text-white font-medium text-sm mt-1 break-all">
                    {user.address}
                  </div>
                </div>
                
                {withdrawMessage.text && (
                  <div className={`mb-4 p-3 rounded-lg text-sm ${
                    withdrawMessage.type === 'error' ? 'bg-red-900/50 text-red-300' : 'bg-green-900/50 text-green-300'
                  }`}>
                    {withdrawMessage.text}
                  </div>
                )}
                
                <button
                  onClick={handleWithdraw}
                  disabled={isWithdrawing || withdrawAmount <= 0 || withdrawAmount > user.balance}
                  className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isWithdrawing ? (
                    <div className="flex items-center justify-center">
                      <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Procesando retiro...
                    </div>
                  ) : (
                    'Retirar USDT'
                  )}
                </button>
                
                <div className="mt-4 text-xs text-indigo-400">
                  <p>Los retiros se procesan automáticamente y pueden tardar hasta 30 minutos en completarse.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Últimas Transacciones</h3>
            
            {transactions.length === 0 ? (
              <div className="bg-indigo-800/30 rounded-lg p-4 text-center">
                <p className="text-indigo-300">No tienes transacciones recientes</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-indigo-300 border-b border-indigo-800">
                      <th className="pb-2">Tipo</th>
                      <th className="pb-2">Cantidad</th>
                      <th className="pb-2">Tokens</th>
                      <th className="pb-2">Fecha</th>
                      <th className="pb-2">Estado</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map(tx => (
                      <tr key={tx.id} className="border-b border-indigo-800/30">
                        <td className="py-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            tx.type === 'buy' ? 'bg-green-900/50 text-green-300' : 'bg-red-900/50 text-red-300'
                          }`}>
                            {tx.type === 'buy' ? 'Compra' : 'Venta'}
                          </span>
                        </td>
                        <td className="py-3">{tx.amount.toFixed(2)} USDT</td>
                        <td className="py-3">{tx.tokens} SNK</td>
                        <td className="py-3">{new Date(tx.timestamp).toLocaleString()}</td>
                        <td className="py-3">
                          <span className="text-green-400">
                            {tx.status === 'completed' ? 'Completada' : 'Pendiente'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
        
        <div>
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mb-6">
            <h3 className="text-xl font-bold text-white mb-4">Tu Balance</h3>
            
            <div className="space-y-4">
              <div className="bg-indigo-800/50 rounded-lg p-4">
                <p className="text-sm text-indigo-300">USDT</p>
                <p className="text-2xl font-bold text-yellow-400">{user.balance.toFixed(2)}</p>
              </div>
              
              <div className="bg-indigo-800/50 rounded-lg p-4">
                <p className="text-sm text-indigo-300">SnakeCoin (SNK)</p>
                <p className="text-2xl font-bold text-indigo-400">{user.token}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Retiros Pendientes</h3>
            
            {!user.pendingWithdrawals || user.pendingWithdrawals.length === 0 ? (
              <div className="bg-indigo-800/30 rounded-lg p-4 text-center">
                <p className="text-indigo-300">No tienes retiros pendientes</p>
              </div>
            ) : (
              <div className="space-y-3">
                {user.pendingWithdrawals.map(withdrawal => (
                  <div key={withdrawal.id} className="bg-indigo-800/30 rounded-lg p-3">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white font-medium">{withdrawal.amount.toFixed(2)} USDT</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        withdrawal.status === 'completed' 
                          ? 'bg-green-900/50 text-green-300' 
                          : 'bg-yellow-900/50 text-yellow-300'
                      }`}>
                        {withdrawal.status === 'completed' ? 'Completado' : 'Procesando'}
                      </span>
                    </div>
                    <p className="text-xs text-indigo-400">
                      {new Date(withdrawal.timestamp).toLocaleString()}
                    </p>
                    <p className="text-xs text-indigo-400 truncate">
                      TX: {withdrawal.txHash}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TokenExchangePage;