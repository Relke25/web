import React, { useState } from 'react';
import { userStorage } from '../utilities/storage';

const BecomeInfluencerPage = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    socialMedia: '',
    followers: '',
    description: '',
    walletAddress: '',
    email: '',
    agreeTerms: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  
  const user = userStorage.getStorage();
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validaciones
    if (!formData.name || !formData.socialMedia || !formData.followers || !formData.email || !formData.walletAddress) {
      setMessage({
        text: 'Por favor, completa todos los campos obligatorios',
        type: 'error'
      });
      return;
    }
    
    if (!formData.agreeTerms) {
      setMessage({
        text: 'Debes aceptar los términos y condiciones',
        type: 'error'
      });
      return;
    }
    
    setIsSubmitting(true);
    setMessage({ text: '', type: '' });
    
    // Simulación de envío
    setTimeout(() => {
      // Actualizar estado del usuario
      const updatedUser = { ...user };
      updatedUser.influencerStatus = 'pending';
      updatedUser.influencerWallet = formData.walletAddress;
      
      userStorage.setStorage(updatedUser);
      
      setMessage({
        text: '¡Solicitud enviada con éxito! Revisaremos tu información y te notificaremos pronto.',
        type: 'success'
      });
      
      setIsSubmitting(false);
    }, 2000);
  };
  
  // Si el usuario ya es influencer o tiene una solicitud pendiente
  if (user.influencerStatus === 'verified') {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Programa de Influencers</h2>
          <button
            onClick={() => onNavigate('home')}
            className="text-indigo-400 hover:text-white transition-colors flex items-center"
          >
            <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Volver
          </button>
        </div>
        
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-8 max-w-2xl mx-auto">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-green-900/30 text-green-400 rounded-full px-4 py-2 flex items-center">
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Influencer Verificado
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-white text-center mb-4">¡Felicidades!</h3>
          <p className="text-indigo-300 text-center mb-6">
            Ya eres parte de nuestro programa de influencers. Puedes crear salas personalizadas y ganar comisiones.
          </p>
          
          <div className="bg-indigo-800/30 rounded-lg p-6 mb-6">
            <h4 className="text-lg font-semibold text-white mb-3">Beneficios de tu cuenta</h4>
            <ul className="space-y-2 text-indigo-300">
              <li className="flex items-start">
                <svg className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Comisión del 4% por cada partida en tus salas
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Creación ilimitada de salas personalizadas
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Estadísticas detalladas de tus salas y ganancias
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Soporte prioritario para influencers
              </li>
            </ul>
          </div>
          
          <div className="flex justify-center">
            <button
              onClick={() => onNavigate('influencer')}
              className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg"
            >
              Ir a mi Panel de Influencer
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  if (user.influencerStatus === 'pending') {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Programa de Influencers</h2>
          <button
            onClick={() => onNavigate('home')}
            className="text-indigo-400 hover:text-white transition-colors flex items-center"
          >
            <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Volver
          </button>
        </div>
        
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-8 max-w-2xl mx-auto">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-yellow-900/30 text-yellow-400 rounded-full px-4 py-2 flex items-center">
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Solicitud en Revisión
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-white text-center mb-4">¡Gracias por tu solicitud!</h3>
          <p className="text-indigo-300 text-center mb-6">
            Estamos revisando tu información para verificar tu cuenta de influencer. Este proceso puede tardar hasta 48 horas.
          </p>
          
          <div className="bg-indigo-800/30 rounded-lg p-6 mb-6">
            <h4 className="text-lg font-semibold text-white mb-3">Próximos pasos</h4>
            <ol className="space-y-4 text-indigo-300">
              <li className="flex">
                <div className="bg-indigo-700 rounded-full w-6 h-6 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  1
                </div>
                <div>
                  <p className="font-medium text-white">Revisión de tu solicitud</p>
                  <p className="text-sm">Nuestro equipo está verificando tus datos y redes sociales</p>
                </div>
              </li>
              <li className="flex">
                <div className="bg-indigo-700 rounded-full w-6 h-6 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  2
                </div>
                <div>
                  <p className="font-medium text-white">Notificación por email</p>
                  <p className="text-sm">Te enviaremos un correo con el resultado de tu solicitud</p>
                </div>
              </li>
              <li className="flex">
                <div className="bg-indigo-700 rounded-full w-6 h-6 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  3
                </div>
                <div>
                  <p className="font-medium text-white">Activación de beneficios</p>
                  <p className="text-sm">Una vez aprobada, podrás crear salas y ganar comisiones</p>
                </div>
              </li>
            </ol>
          </div>
          
          <div className="text-center text-indigo-300 text-sm">
            <p>¿Tienes alguna pregunta? Contacta con nuestro equipo de soporte.</p>
            <button
              onClick={() => onNavigate('support')}
              className="text-yellow-400 hover:text-yellow-300 font-medium mt-2"
            >
              Ir a Soporte
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Programa de Influencers</h2>
        <button
          onClick={() => onNavigate('home')}
          className="text-indigo-400 hover:text-white transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Volver
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
            <h3 className="text-xl font-bold text-white mb-6">Solicitud de Influencer</h3>
            
            {message.text && (
              <div className={`mb-6 p-4 rounded-lg ${
                message.type === 'error' ? 'bg-red-900/50 text-red-300' : 'bg-green-900/50 text-green-300'
              }`}>
                {message.text}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm text-indigo-300 mb-2">
                    Nombre completo *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Tu nombre completo"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-indigo-300 mb-2">
                    Email de contacto *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="tu@email.com"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-indigo-300 mb-2">
                    Red social principal *
                  </label>
                  <input
                    type="text"
                    name="socialMedia"
                    value={formData.socialMedia}
                    onChange={handleChange}
                    className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="@tuusuario o URL"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-indigo-300 mb-2">
                    Número de seguidores *
                  </label>
                  <input
                    type="text"
                    name="followers"
                    value={formData.followers}
                    onChange={handleChange}
                    className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Ej: 10,000"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm text-indigo-300 mb-2">
                    Wallet para recibir comisiones *
                  </label>
                  <input
                    type="text"
                    name="walletAddress"
                    value={formData.walletAddress}
                    onChange={handleChange}
                    className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="0x..."
                    defaultValue={user.address}
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm text-indigo-300 mb-2">
                    Cuéntanos sobre ti y tu contenido
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows="4"
                    className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                    placeholder="Describe tu contenido, audiencia y por qué quieres ser influencer de SnakeBet"
                  ></textarea>
                </div>
                
                <div className="md:col-span-2">
                  <div className="flex items-start">
                    <input
                      id="terms"
                      name="agreeTerms"
                      type="checkbox"
                      checked={formData.agreeTerms}
                      onChange={handleChange}
                      className="mt-1 h-4 w-4 text-indigo-600 bg-indigo-800 border-indigo-700 rounded focus:ring-indigo-500"
                    />
                    <label htmlFor="terms" className="ml-2 text-sm text-indigo-300">
                      Acepto los términos y condiciones del programa de influencers, incluyendo la promoción responsable del juego y el cumplimiento de las normativas aplicables.
                    </label>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <div className="flex items-center">
                      <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Enviando solicitud...
                    </div>
                  ) : (
                    'Enviar Solicitud'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
        
        <div>
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6 mb-6">
            <h3 className="text-xl font-bold text-white mb-4">Beneficios para Influencers</h3>
            
            <div className="space-y-4">
              <div className="flex">
                <div className="bg-yellow-600 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" fill="currentColor"/>
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Crea tus propias salas</p>
                  <p className="text-sm text-indigo-300">Personaliza salas privadas para tus seguidores</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="bg-yellow-600 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z" fill="currentColor"/>
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Gana comisiones</p>
                  <p className="text-sm text-indigo-300">4% de todas las apuestas en tus salas</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="bg-yellow-600 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" fill="currentColor"/>
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Certificación oficial</p>
                  <p className="text-sm text-indigo-300">Distintivo de influencer verificado</p>
                </div>
              </div>
              
              <div className="flex">
                <div className="bg-yellow-600 rounded-full w-8 h-8 flex items-center justify-center text-white font-bold mr-3 flex-shrink-0">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" fill="currentColor"/>
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Estadísticas detalladas</p>
                  <p className="text-sm text-indigo-300">Panel exclusivo con métricas y ganancias</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Requisitos</h3>
            
            <div className="space-y-3 text-indigo-300">
              <p className="flex items-start">
                <svg className="w-5 h-5 text-yellow-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
                </svg>
                Mínimo 1,000 seguidores en alguna red social
              </p>
              <p className="flex items-start">
                <svg className="w-5 h-5 text-yellow-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
                </svg>
                Contenido relacionado con gaming, crypto o apuestas
              </p>
              <p className="flex items-start">
                <svg className="w-5 h-5 text-yellow-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
                </svg>
                Promoción responsable del juego
              </p>
              <p className="flex items-start">
                <svg className="w-5 h-5 text-yellow-400 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
                </svg>
                Compartir regularmente contenido sobre SnakeBet
              </p>
            </div>
            
            <div className="mt-6 pt-4 border-t border-indigo-800">
              <p className="text-sm text-indigo-300">
                Revisamos cada solicitud cuidadosamente. El proceso de verificación puede tardar hasta 48 horas.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BecomeInfluencerPage;