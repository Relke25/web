import React, { useState } from 'react';
import { userStorage } from '../utilities/storage';

const Header = ({ onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const user = userStorage.getStorage();
  
  return (
    <header className="bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-900 text-white shadow-lg">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => onNavigate('home')}
            className="text-2xl font-bold tracking-tight flex items-center"
          >
            <svg className="w-8 h-8 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/>
              <path d="M15 8h-2v4h-4V8H7v8h2v-2h6v2h2V8z" fill="currentColor"/>
            </svg>
            SnakeBet
          </button>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          <button 
            onClick={() => onNavigate('home')}
            className="text-white hover:text-yellow-300 transition-colors"
          >
            Inicio
          </button>
          <button 
            onClick={() => onNavigate('createRoom')}
            className="text-white hover:text-yellow-300 transition-colors"
          >
            Crear Sala
          </button>
          <button 
            onClick={() => onNavigate('joinPrivate')}
            className="text-white hover:text-yellow-300 transition-colors"
          >
            Unirse a Sala
          </button>
          <button 
            onClick={() => onNavigate('exchange')}
            className="text-white hover:text-yellow-300 transition-colors"
          >
            Intercambio
          </button>
          {user.isInfluencer ? (
            <button 
              onClick={() => onNavigate('influencer')}
              className="text-white hover:text-yellow-300 transition-colors"
            >
              Panel Influencer
            </button>
          ) : (
            <button 
              onClick={() => onNavigate('becomeInfluencer')}
              className="text-white hover:text-yellow-300 transition-colors"
            >
              Ser Influencer
            </button>
          )}
          <button 
            onClick={() => onNavigate('support')}
            className="text-white hover:text-yellow-300 transition-colors"
          >
            Soporte
          </button>
        </div>
        
        <div className="flex items-center space-x-4">
          {user.isConnected ? (
            <>
              <div className="hidden sm:flex items-center bg-indigo-800 rounded-full px-4 py-1">
                <div className="mr-2">
                  <div className="text-xs text-indigo-300">USDT</div>
                  <div className="font-medium">{user.balance.toFixed(2)}</div>
                </div>
                <div className="h-8 w-px bg-indigo-700"></div>
                <div className="ml-2">
                  <div className="text-xs text-indigo-300">SNK</div>
                  <div className="font-medium">{user.token}</div>
                </div>
              </div>
              
              <button 
                onClick={() => onNavigate('profile')}
                className="bg-indigo-700 hover:bg-indigo-600 rounded-full p-2 transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12ZM12 14C9.33 14 4 15.34 4 18V20H20V18C20 15.34 14.67 14 12 14Z" fill="currentColor"/>
                </svg>
              </button>
            </>
          ) : (
            <button 
              onClick={() => onNavigate('connect')}
              className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-2 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
            >
              Conectar Wallet
            </button>
          )}
          
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden bg-indigo-800 p-2 rounded-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </div>
      
      {/* Menú móvil */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-indigo-900 py-2">
          <div className="container mx-auto px-4 space-y-2">
            <button 
              onClick={() => {
                onNavigate('home');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
            >
              Inicio
            </button>
            <button 
              onClick={() => {
                onNavigate('createRoom');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
            >
              Crear Sala
            </button>
            <button 
              onClick={() => {
                onNavigate('joinPrivate');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
            >
              Unirse a Sala
            </button>
            <button 
              onClick={() => {
                onNavigate('exchange');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
            >
              Intercambio
            </button>
            {user.isInfluencer ? (
              <button 
                onClick={() => {
                  onNavigate('influencer');
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
              >
                Panel Influencer
              </button>
            ) : (
              <button 
                onClick={() => {
                  onNavigate('becomeInfluencer');
                  setMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
              >
                Ser Influencer
              </button>
            )}
            <button 
              onClick={() => {
                onNavigate('support');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left py-2 px-3 hover:bg-indigo-800 rounded-lg"
            >
              Soporte
            </button>
            
            {user.isConnected && (
              <div className="flex items-center bg-indigo-800 rounded-lg p-3 mt-2">
                <div className="mr-3">
                  <div className="text-xs text-indigo-300">USDT</div>
                  <div className="font-medium">{user.balance.toFixed(2)}</div>
                </div>
                <div className="h-8 w-px bg-indigo-700"></div>
                <div className="ml-3">
                  <div className="text-xs text-indigo-300">SNK</div>
                  <div className="font-medium">{user.token}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;