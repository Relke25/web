import React from 'react';

const RoomCard = ({ room, onJoin }) => {
  const isWaiting = room.status === 'waiting';
  const isStarting = room.status === 'starting';
  const isActive = room.status === 'active';
  
  const getStatusColor = () => {
    if (isWaiting) return 'bg-green-500';
    if (isStarting) return 'bg-yellow-500';
    if (isActive) return 'bg-red-500';
    return 'bg-gray-500';
  };
  
  const getStatusText = () => {
    if (isWaiting) return 'Esperando jugadores';
    if (isStarting) return 'Iniciando partida';
    if (isActive) return 'Partida en curso';
    return 'Finalizada';
  };
  
  const getProgressPercentage = () => {
    return (room.currentPlayers / room.maxPlayers) * 100;
  };
  
  const getRoomTypeLabel = () => {
    switch(room.type) {
      case 'free':
        return (
          <span className="bg-green-900 text-green-300 text-xs px-2 py-1 rounded-full">
            Gratis
          </span>
        );
      case 'standard':
        return null;
      case 'private':
        return (
          <span className="bg-purple-900 text-purple-300 text-xs px-2 py-1 rounded-full">
            Privada
          </span>
        );
      case 'influencer':
        return (
          <span className="bg-yellow-900 text-yellow-300 text-xs px-2 py-1 rounded-full">
            Influencer
          </span>
        );
      default:
        return null;
    }
  };
  
  const getGameModeLabel = () => {
    if (room.gameMode === 'survival') {
      return (
        <span className="bg-blue-900 text-blue-300 text-xs px-2 py-1 rounded-full ml-1">
          Supervivencia
        </span>
      );
    }
    return null;
  };
  
  return (
    <div className="bg-gradient-to-br from-gray-900 to-indigo-900 rounded-xl shadow-xl overflow-hidden transition-all hover:shadow-2xl hover:scale-[1.02] transform duration-300">
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center flex-wrap">
            <h3 className="text-xl font-bold text-white mr-2">{room.name}</h3>
            {getRoomTypeLabel()}
            {getGameModeLabel()}
          </div>
          <div className="flex items-center">
            <span className={`${getStatusColor()} w-2 h-2 rounded-full mr-2`}></span>
            <span className="text-xs text-gray-300">{getStatusText()}</span>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between text-sm text-gray-400 mb-1">
            <span>Jugadores</span>
            <span>{room.currentPlayers}/{room.maxPlayers}</span>
          </div>
          <div className="w-full bg-gray-800 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-purple-500 to-indigo-500 h-2 rounded-full" 
              style={{ width: `${getProgressPercentage()}%` }}
            ></div>
          </div>
          {room.gameMode === 'classic' ? (
            <p className="text-xs text-gray-500 mt-1">
              Inicia con {room.minPlayersToStart} jugadores
            </p>
          ) : (
            <p className="text-xs text-gray-500 mt-1">
              Supervivencia: {Math.floor(room.survivalTime / 60)} minutos
            </p>
          )}
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <div>
            <p className="text-sm text-gray-400">Entrada</p>
            <p className="text-xl font-bold text-yellow-400">
              {room.entryFee === 0 ? 'Gratis' : `${room.entryFee} USDT`}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Premio potencial</p>
            <p className="text-xl font-bold text-green-400">
              {room.entryFee === 0 ? 
                '0 USDT' : 
                `${Math.floor(room.maxPlayers * room.entryFee * 0.9)} USDT`}
            </p>
            {room.entryFee > 0 && (
              <p className="text-xs text-gray-500 text-right">
                Comisión: 10%
              </p>
            )}
          </div>
        </div>
        
        {room.type === 'private' && (
          <div className="mb-4 bg-indigo-800/30 rounded-lg p-2">
            <p className="text-xs text-indigo-300">ID de sala: {room.roomId || 'N/A'}</p>
            {room.createdBy && (
              <p className="text-xs text-indigo-300">Creada por: {room.createdBy}</p>
            )}
          </div>
        )}
        
        <button
          onClick={() => onJoin(room)}
          disabled={isActive || isStarting}
          className={`w-full py-3 rounded-lg font-medium transition-all ${
            isActive || isStarting
              ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white shadow-lg hover:shadow-xl'
          }`}
        >
          {isActive || isStarting ? 'No disponible' : 'Unirse a la sala'}
        </button>
      </div>
    </div>
  );
};

export default RoomCard;