import React, { useState } from 'react';
import { userStorage, privateRoomsStorage } from '../utilities/storage';

const CreateRoomForm = ({ onRoomCreated, onCancel }) => {
  const [roomName, setRoomName] = useState('');
  const [entryFee, setEntryFee] = useState(1);
  const [maxPlayers, setMaxPlayers] = useState(100);
  const [minPlayersToStart, setMinPlayersToStart] = useState(2);
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState('');
  const [roomType, setRoomType] = useState('private'); // 'private' o 'influencer'
  const [gameMode, setGameMode] = useState('classic'); // 'classic' o 'survival'
  const [survivalTime, setSurvivalTime] = useState(300); // 5 minutos en segundos
  
  const user = userStorage.getStorage();
  
  const handleCreateRoom = () => {
    // Validaciones
    if (!roomName.trim()) {
      setError('El nombre de la sala es obligatorio');
      return;
    }
    
    if (entryFee < 0) {
      setError('La tarifa de entrada no puede ser negativa');
      return;
    }
    
    if (maxPlayers < 2 || maxPlayers > 100) {
      setError('El número de jugadores debe estar entre 2 y 100');
      return;
    }
    
    if (minPlayersToStart < 2 || minPlayersToStart > maxPlayers) {
      setError(`El mínimo de jugadores debe estar entre 2 y ${maxPlayers}`);
      return;
    }
    
    setIsCreating(true);
    setError('');
    
    // Simulación de creación de sala
    setTimeout(() => {
      // Generar ID único para la sala
      const roomId = Math.random().toString(36).substr(2, 8).toUpperCase();
      
      // Crear nueva sala
      const newRoom = {
        id: Date.now(),
        name: roomName,
        entryFee: parseFloat(entryFee),
        maxPlayers: parseInt(maxPlayers),
        minPlayersToStart: parseInt(minPlayersToStart),
        currentPlayers: 0,
        status: 'waiting',
        startTime: null,
        type: user.isInfluencer && roomType === 'influencer' ? 'influencer' : 'private',
        gameMode: gameMode,
        roomId: roomId,
        createdBy: user.address.substring(0, 6) + '...' + user.address.substring(user.address.length - 4),
        creatorAddress: user.address,
        creatorInfluencerId: user.isInfluencer && roomType === 'influencer' ? user.influencerWallet : null
      };
      
      // Añadir tiempo de supervivencia si es modo supervivencia
      if (gameMode === 'survival') {
        newRoom.survivalTime = parseInt(survivalTime);
      }
      
      // Guardar la sala en el almacenamiento
      const privateRooms = privateRoomsStorage.getStorage();
      privateRoomsStorage.setStorage([...privateRooms, newRoom]);
      
      setIsCreating(false);
      onRoomCreated(newRoom);
    }, 1500);
  };
  
  return (
    <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
      <h3 className="text-xl font-bold text-white mb-6">
        Crear Sala {user.isInfluencer ? (roomType === 'influencer' ? 'de Influencer' : 'Privada') : 'Privada'}
      </h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-indigo-300 mb-2">
            Nombre de la sala
          </label>
          <input
            type="text"
            value={roomName}
            onChange={(e) => setRoomName(e.target.value)}
            placeholder="Ej: Sala de amigos"
            className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        
        {user.isInfluencer && (
          <div>
            <label className="block text-sm text-indigo-300 mb-2">
              Tipo de sala
            </label>
            <div className="flex bg-indigo-800 rounded-lg p-1">
              <button
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                  roomType === 'private' 
                    ? 'bg-indigo-600 text-white' 
                    : 'text-indigo-300 hover:text-white'
                }`}
                onClick={() => setRoomType('private')}
              >
                Sala Privada
              </button>
              <button
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                  roomType === 'influencer' 
                    ? 'bg-indigo-600 text-white' 
                    : 'text-indigo-300 hover:text-white'
                }`}
                onClick={() => setRoomType('influencer')}
              >
                Sala de Influencer
              </button>
            </div>
            {roomType === 'influencer' && (
              <p className="mt-1 text-xs text-indigo-400">
                Recibirás el 4% de comisión por cada partida en esta sala.
              </p>
            )}
          </div>
        )}
        
        <div>
          <label className="block text-sm text-indigo-300 mb-2">
            Modo de juego
          </label>
          <div className="flex bg-indigo-800 rounded-lg p-1">
            <button
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                gameMode === 'classic' 
                  ? 'bg-indigo-600 text-white' 
                  : 'text-indigo-300 hover:text-white'
              }`}
              onClick={() => setGameMode('classic')}
            >
              Clásico
            </button>
            <button
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                gameMode === 'survival' 
                  ? 'bg-indigo-600 text-white' 
                  : 'text-indigo-300 hover:text-white'
              }`}
              onClick={() => setGameMode('survival')}
            >
              Supervivencia
            </button>
          </div>
          {gameMode === 'survival' && (
            <p className="mt-1 text-xs text-indigo-400">
              Los jugadores que sobrevivan {Math.floor(survivalTime / 60)} minutos se repartirán el premio.
            </p>
          )}
        </div>
        
        <div>
          <label className="block text-sm text-indigo-300 mb-2">
            Tarifa de entrada (USDT)
          </label>
          <input
            type="number"
            min="0"
            step="0.1"
            value={entryFee}
            onChange={(e) => setEntryFee(e.target.value)}
            className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-indigo-300 mb-2">
              Número máximo de jugadores
            </label>
            <input
              type="number"
              min="2"
              max="100"
              value={maxPlayers}
              onChange={(e) => setMaxPlayers(parseInt(e.target.value))}
              className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          
          <div>
            <label className="block text-sm text-indigo-300 mb-2">
              Mínimo para iniciar
            </label>
            <input
              type="number"
              min="2"
              max={maxPlayers}
              value={minPlayersToStart}
              onChange={(e) => setMinPlayersToStart(parseInt(e.target.value))}
              className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
        
        {gameMode === 'survival' && (
          <div>
            <label className="block text-sm text-indigo-300 mb-2">
              Tiempo de supervivencia (minutos)
            </label>
            <input
              type="number"
              min="1"
              max="10"
              value={survivalTime / 60}
              onChange={(e) => setSurvivalTime(parseInt(e.target.value) * 60)}
              className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        )}
        
        {error && (
          <div className="p-3 bg-red-900/50 text-red-300 rounded-lg text-sm">
            {error}
          </div>
        )}
        
        <div className="flex space-x-4 pt-4">
          <button
            onClick={onCancel}
            className="flex-1 bg-indigo-800 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          
          <button
            onClick={handleCreateRoom}
            disabled={isCreating}
            className="flex-1 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isCreating ? (
              <div className="flex items-center justify-center">
                <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Creando...
              </div>
            ) : (
              'Crear Sala'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateRoomForm;