import React, { useEffect, useRef, useState } from 'react';
import { userStorage } from '../utilities/storage';
import snakeSkins from '../mock/snakeSkins';

const GameCanvas = ({ gameState, playerId, onMove }) => {
  const canvasRef = useRef(null);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  
  // Obtener el skin seleccionado por el usuario
  const user = userStorage.getStorage();
  const selectedSkinId = user.selectedSkin || 1;
  const selectedSkin = snakeSkins.find(skin => skin.id === selectedSkinId) || snakeSkins[0];
  
  // Configurar el tamaño del canvas
  useEffect(() => {
    const updateCanvasSize = () => {
      const container = canvasRef.current.parentElement;
      const width = container.clientWidth;
      const height = container.clientHeight;
      setCanvasSize({ width, height });
    };
    
    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);
    
    return () => {
      window.removeEventListener('resize', updateCanvasSize);
    };
  }, []);
  
  // Renderizar el juego
  useEffect(() => {
    if (!canvasRef.current || !gameState || canvasSize.width === 0) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Limpiar canvas
    ctx.clearRect(0, 0, canvasSize.width, canvasSize.height);
    
    // Dibujar fondo
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvasSize.width, canvasSize.height);
    
    // Dibujar límites del mapa
    const { mapSize, shrinkFactor } = gameState;
    const gridSize = Math.min(canvasSize.width, canvasSize.height) / mapSize;
    
    // Dibujar cuadrícula
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= mapSize; i++) {
      // Líneas verticales
      ctx.beginPath();
      ctx.moveTo(i * gridSize, 0);
      ctx.lineTo(i * gridSize, mapSize * gridSize);
      ctx.stroke();
      
      // Líneas horizontales
      ctx.beginPath();
      ctx.moveTo(0, i * gridSize);
      ctx.lineTo(mapSize * gridSize, i * gridSize);
      ctx.stroke();
    }
    
    // Dibujar límite de encogimiento
    const shrinkBorder = Math.floor(mapSize * (1 - shrinkFactor) / 2);
    const shrinkSize = mapSize - (shrinkBorder * 2);
    
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 3;
    ctx.strokeRect(
      shrinkBorder * gridSize, 
      shrinkBorder * gridSize, 
      shrinkSize * gridSize, 
      shrinkSize * gridSize
    );
    
    // Dibujar comida
    gameState.food.forEach(food => {
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.arc(
        (food.x + 0.5) * gridSize, 
        (food.y + 0.5) * gridSize, 
        gridSize / 3, 
        0, 
        Math.PI * 2
      );
      ctx.fill();
    });
    
    // Dibujar obstáculos
    gameState.obstacles.forEach(obstacle => {
      ctx.fillStyle = '#7c3aed';
      ctx.fillRect(
        obstacle.x * gridSize,
        obstacle.y * gridSize,
        gridSize,
        gridSize
      );
    });
    
    // Dibujar serpientes
    gameState.players.forEach(player => {
      // Determinar el skin a usar
      let skin;
      if (player.id === playerId) {
        // Usar el skin seleccionado por el jugador actual
        skin = selectedSkin;
      } else {
        // Para otros jugadores, usar un skin aleatorio pero consistente basado en su ID
        const skinIndex = Math.abs(player.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)) % snakeSkins.length;
        skin = snakeSkins[skinIndex];
      }
      
      // Colores de la serpiente basados en el skin
      const headColor = skin.headColor;
      const bodyColor = skin.bodyColor;
      const eyeColor = skin.eyeColor;
      
      // Dibujar cuerpo
      player.snake.body.forEach((segment, index) => {
        // La cabeza tiene un color diferente
        ctx.fillStyle = index === 0 ? headColor : bodyColor;
        
        // Aplicar efectos según el patrón
        if (skin.pattern === 'glow') {
          ctx.shadowColor = index === 0 ? headColor : bodyColor;
          ctx.shadowBlur = 10;
        } else {
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
        }
        
        // Dibujar segmento
        ctx.fillRect(
          segment.x * gridSize,
          segment.y * gridSize,
          gridSize,
          gridSize
        );
        
        // Patrones especiales
        if (skin.pattern === 'striped' && index % 2 === 1) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
          ctx.fillRect(
            segment.x * gridSize,
            segment.y * gridSize,
            gridSize,
            gridSize
          );
        } else if (skin.pattern === 'diamond' && index % 2 === 1) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
          ctx.beginPath();
          ctx.moveTo(segment.x * gridSize + gridSize/2, segment.y * gridSize);
          ctx.lineTo(segment.x * gridSize + gridSize, segment.y * gridSize + gridSize/2);
          ctx.lineTo(segment.x * gridSize + gridSize/2, segment.y * gridSize + gridSize);
          ctx.lineTo(segment.x * gridSize, segment.y * gridSize + gridSize/2);
          ctx.closePath();
          ctx.fill();
        }
        
        // Añadir ojos a la cabeza
        if (index === 0) {
          ctx.fillStyle = eyeColor;
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
          
          // Posición de los ojos según la dirección
          const eyeSize = gridSize / 5;
          const eyeOffset = gridSize / 3;
          
          // Ojo izquierdo
          ctx.beginPath();
          ctx.arc(
            segment.x * gridSize + eyeOffset, 
            segment.y * gridSize + eyeOffset, 
            eyeSize, 
            0, 
            Math.PI * 2
          );
          ctx.fill();
          
          // Ojo derecho
          ctx.beginPath();
          ctx.arc(
            segment.x * gridSize + gridSize - eyeOffset, 
            segment.y * gridSize + eyeOffset, 
            eyeSize, 
            0, 
            Math.PI * 2
          );
          ctx.fill();
        }
      });
    });
    
    // Dibujar puntuaciones
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Jugadores: ${gameState.players.length}`, 10, 20);
    
    // Mostrar tiempo restante para encogimiento
    if (gameState.nextShrinkTime) {
      const timeLeft = Math.max(0, Math.floor((gameState.nextShrinkTime - Date.now()) / 1000));
      ctx.fillText(`Encogimiento en: ${timeLeft}s`, 10, 40);
    }
    
    // Mostrar tiempo de supervivencia si es modo supervivencia
    if (gameState.survivalTimeRemaining) {
      const minutes = Math.floor(gameState.survivalTimeRemaining / 60);
      const seconds = gameState.survivalTimeRemaining % 60;
      ctx.fillText(`Supervivencia: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`, 10, 60);
    }
    
  }, [gameState, canvasSize, playerId, selectedSkin]);
  
  // Manejar eventos de teclado
  useEffect(() => {
    const handleKeyDown = (e) => {
      switch (e.key) {
        case 'ArrowUp':
          onMove('up');
          break;
        case 'ArrowDown':
          onMove('down');
          break;
        case 'ArrowLeft':
          onMove('left');
          break;
        case 'ArrowRight':
          onMove('right');
          break;
        default:
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onMove]);
  
  return (
    <canvas
      ref={canvasRef}
      width={canvasSize.width}
      height={canvasSize.height}
      className="rounded-lg shadow-lg"
    />
  );
};

export default GameCanvas;