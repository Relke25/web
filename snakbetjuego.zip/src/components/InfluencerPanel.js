import React, { useState, useEffect } from 'react';
import { userStorage, privateRoomsStorage } from '../utilities/storage';

const InfluencerPanel = ({ onNavigate }) => {
  const [myRooms, setMyRooms] = useState([]);
  const [totalCommission, setTotalCommission] = useState(0);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalPlayers: 0,
    activeRooms: 0,
    completedGames: 0
  });
  
  const user = userStorage.getStorage();
  
  useEffect(() => {
    // Cargar salas creadas por el influencer
    const privateRooms = privateRoomsStorage.getStorage();
    const influencerRooms = privateRooms.filter(room => 
      room.type === 'influencer' && 
      room.creatorAddress === user.address
    );
    
    setMyRooms(influencerRooms);
    
    // Calcular comisión total (simulada)
    const commission = influencerRooms.length * 2.5; // Valor simulado
    setTotalCommission(commission);
    
    // Estadísticas simuladas
    setStats({
      totalPlayers: influencerRooms.reduce((acc, room) => acc + room.currentPlayers, 0),
      activeRooms: influencerRooms.filter(room => room.status === 'waiting' || room.status === 'starting').length,
      completedGames: Math.floor(Math.random() * 20) // Simulado
    });
    
    setLoading(false);
  }, [user.address]);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Panel de Influencer</h2>
        <button
          onClick={() => onNavigate('home')}
          className="text-indigo-400 hover:text-white transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Volver
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
          <div className="flex items-center mb-4">
            <div className="bg-yellow-900/30 text-yellow-400 rounded-full px-3 py-1 text-sm">
              Influencer Verificado
            </div>
          </div>
          
          <h3 className="text-xl font-bold text-white mb-4">Resumen</h3>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm text-indigo-300">Wallet para comisiones</p>
              <p className="text-md text-white break-all">{user.influencerWallet || user.address}</p>
            </div>
            
            <div>
              <p className="text-sm text-indigo-300">Salas creadas</p>
              <p className="text-2xl font-bold text-white">{myRooms.length}</p>
            </div>
            
            <div>
              <p className="text-sm text-indigo-300">Comisión total ganada</p>
              <p className="text-2xl font-bold text-yellow-400">{totalCommission.toFixed(2)} USDT</p>
              <p className="text-xs text-indigo-400">4% de todas las apuestas en tus salas</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
          <h3 className="text-xl font-bold text-white mb-4">Estadísticas</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-indigo-800/50 rounded-lg p-4">
              <p className="text-sm text-indigo-300">Jugadores totales</p>
              <p className="text-2xl font-bold text-white">{stats.totalPlayers}</p>
            </div>
            
            <div className="bg-indigo-800/50 rounded-lg p-4">
              <p className="text-sm text-indigo-300">Salas activas</p>
              <p className="text-2xl font-bold text-white">{stats.activeRooms}</p>
            </div>
            
            <div className="bg-indigo-800/50 rounded-lg p-4">
              <p className="text-sm text-indigo-300">Partidas completadas</p>
              <p className="text-2xl font-bold text-white">{stats.completedGames}</p>
            </div>
            
            <div className="bg-indigo-800/50 rounded-lg p-4">
              <p className="text-sm text-indigo-300">Tasa de comisión</p>
              <p className="text-2xl font-bold text-white">4%</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
          <h3 className="text-xl font-bold text-white mb-4">Acciones rápidas</h3>
          
          <div className="space-y-3">
            <button
              onClick={() => onNavigate('createRoom')}
              className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center"
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Crear Nueva Sala
            </button>
            
            <button
              onClick={() => onNavigate('exchange')}
              className="w-full bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center"
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z" fill="currentColor"/>
              </svg>
              Retirar Comisiones
            </button>
            
            <button
              onClick={() => onNavigate('support')}
              className="w-full bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center"
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 9h-2V5h2v6zm0 4h-2v-2h2v2z" fill="currentColor"/>
              </svg>
              Soporte Prioritario
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-white">Mis Salas</h3>
            
            <button
              onClick={() => onNavigate('createRoom')}
              className="bg-indigo-800 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors text-sm flex items-center"
            >
              <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Nueva Sala
            </button>
          </div>
          
          {loading ? (
            <div className="flex justify-center py-8">
              <svg className="animate-spin h-8 w-8 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </div>
          ) : myRooms.length === 0 ? (
            <div className="bg-indigo-800/30 rounded-lg p-8 text-center">
              <p className="text-indigo-300 mb-4">Aún no has creado ninguna sala</p>
              <button
                onClick={() => onNavigate('createRoom')}
                className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-2 px-4 rounded-lg transition-all shadow-md hover:shadow-lg"
              >
                Crear mi primera sala
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {myRooms.map(room => (
                <div key={room.id} className="bg-indigo-800/30 rounded-lg p-4 flex justify-between items-center">
                  <div>
                    <h4 className="font-medium text-white">{room.name}</h4>
                    <div className="flex items-center mt-1">
                      <span className="text-xs text-indigo-300 mr-4">ID: {room.roomId}</span>
                      <span className="text-xs text-indigo-300">{room.entryFee} USDT</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="text-right mr-4">
                      <p className="text-xs text-indigo-300">Jugadores</p>
                      <p className="text-sm text-white">{room.currentPlayers}/{room.maxPlayers}</p>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-xs text-indigo-300">Comisión est.</p>
                      <p className="text-sm text-yellow-400">
                        {(room.entryFee * room.maxPlayers * 0.04).toFixed(2)} USDT
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-6">
          <h3 className="text-xl font-bold text-white mb-4">Recursos para Influencers</h3>
          
          <div className="space-y-4">
            <div className="bg-indigo-800/30 rounded-lg p-4">
              <h4 className="font-medium text-white mb-2">Materiales promocionales</h4>
              <p className="text-sm text-indigo-300 mb-3">
                Descarga banners, logos y otros materiales para promocionar tus salas.
              </p>
              <button className="text-yellow-400 hover:text-yellow-300 text-sm font-medium">
                Descargar materiales
              </button>
            </div>
            
            <div className="bg-indigo-800/30 rounded-lg p-4">
              <h4 className="font-medium text-white mb-2">Código de referido</h4>
              <p className="text-sm text-indigo-300 mb-3">
                Comparte este código con tus seguidores para que se unan a tus salas.
              </p>
              <div className="bg-indigo-900 rounded-lg p-2 flex justify-between items-center">
                <code className="text-yellow-400 font-mono">INF-{user.address.substring(2, 8)}</code>
                <button className="text-indigo-300 hover:text-white">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
              </div>
            </div>
            
            <div className="bg-indigo-800/30 rounded-lg p-4">
              <h4 className="font-medium text-white mb-2">Guía para influencers</h4>
              <p className="text-sm text-indigo-300 mb-3">
                Aprende cómo maximizar tus ganancias y promocionar efectivamente tus salas.
              </p>
              <button className="text-yellow-400 hover:text-yellow-300 text-sm font-medium">
                Ver guía completa
              </button>
            </div>
            
            <div className="bg-indigo-800/30 rounded-lg p-4">
              <h4 className="font-medium text-white mb-2">Soporte prioritario</h4>
              <p className="text-sm text-indigo-300 mb-3">
                Como influencer verificado, tienes acceso a soporte prioritario.
              </p>
              <button 
                onClick={() => onNavigate('support')}
                className="text-yellow-400 hover:text-yellow-300 text-sm font-medium"
              >
                Contactar soporte
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfluencerPanel;