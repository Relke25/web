import React, { useState, useEffect } from 'react';
import { userStorage, supportTicketsStorage } from '../utilities/storage';

const SupportPage = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState('newTicket');
  const [tickets, setTickets] = useState([]);
  const [ticketForm, setTicketForm] = useState({
    subject: '',
    message: '',
    category: 'general'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  
  const user = userStorage.getStorage();
  
  // Cargar tickets del usuario
  useEffect(() => {
    if (user.isConnected) {
      const allTickets = supportTicketsStorage.getStorage();
      const userTickets = allTickets.filter(ticket => ticket.userId === user.address);
      setTickets(userTickets);
    }
  }, [user.address, user.isConnected]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTicketForm({
      ...ticketForm,
      [name]: value
    });
  };
  
  const handleSubmitTicket = (e) => {
    e.preventDefault();
    
    if (!ticketForm.subject.trim() || !ticketForm.message.trim()) {
      setMessage({
        text: 'Por favor, completa todos los campos obligatorios',
        type: 'error'
      });
      return;
    }
    
    setIsSubmitting(true);
    setMessage({ text: '', type: '' });
    
    // Simulación de envío
    setTimeout(() => {
      const newTicket = {
        id: Date.now(),
        userId: user.address,
        subject: ticketForm.subject,
        message: ticketForm.message,
        category: ticketForm.category,
        status: 'open',
        createdAt: new Date().toISOString(),
        responses: []
      };
      
      const allTickets = supportTicketsStorage.getStorage();
      supportTicketsStorage.setStorage([...allTickets, newTicket]);
      
      setTickets([...tickets, newTicket]);
      setTicketForm({
        subject: '',
        message: '',
        category: 'general'
      });
      
      setMessage({
        text: 'Tu ticket ha sido enviado correctamente. Te responderemos lo antes posible.',
        type: 'success'
      });
      
      setIsSubmitting(false);
      setActiveTab('myTickets');
    }, 1500);
  };
  
  // Si el usuario no está conectado
  if (!user.isConnected) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Soporte</h2>
          <button
            onClick={() => onNavigate('home')}
            className="text-indigo-400 hover:text-white transition-colors flex items-center"
          >
            <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Volver
          </button>
        </div>
        
        <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl p-8 max-w-md mx-auto text-center">
          <svg className="w-16 h-16 text-indigo-400 mx-auto mb-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
          </svg>
          
          <h3 className="text-xl font-bold text-white mb-2">Necesitas iniciar sesión</h3>
          <p className="text-indigo-300 mb-6">
            Para acceder al soporte, primero debes conectar tu wallet.
          </p>
          
          <button
            onClick={() => onNavigate('connect')}
            className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg"
          >
            Conectar Wallet
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Soporte</h2>
        <button
          onClick={() => onNavigate('home')}
          className="text-indigo-400 hover:text-white transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Volver
        </button>
      </div>
      
      <div className="bg-gradient-to-b from-indigo-900 to-purple-900 rounded-xl shadow-xl overflow-hidden">
        <div className="flex border-b border-indigo-800">
          <button
            className={`flex-1 py-4 px-6 text-center font-medium transition-colors ${
              activeTab === 'newTicket' 
                ? 'bg-indigo-800 text-white' 
                : 'text-indigo-300 hover:bg-indigo-800/50 hover:text-white'
            }`}
            onClick={() => setActiveTab('newTicket')}
          >
            Nuevo Ticket
          </button>
          <button
            className={`flex-1 py-4 px-6 text-center font-medium transition-colors ${
              activeTab === 'myTickets' 
                ? 'bg-indigo-800 text-white' 
                : 'text-indigo-300 hover:bg-indigo-800/50 hover:text-white'
            }`}
            onClick={() => setActiveTab('myTickets')}
          >
            Mis Tickets {tickets.length > 0 && `(${tickets.length})`}
          </button>
          <button
            className={`flex-1 py-4 px-6 text-center font-medium transition-colors ${
              activeTab === 'faq' 
                ? 'bg-indigo-800 text-white' 
                : 'text-indigo-300 hover:bg-indigo-800/50 hover:text-white'
            }`}
            onClick={() => setActiveTab('faq')}
          >
            FAQ
          </button>
        </div>
        
        <div className="p-6">
          {activeTab === 'newTicket' && (
            <div>
              <h3 className="text-xl font-bold text-white mb-6">Crear Nuevo Ticket</h3>
              
              {message.text && (
                <div className={`mb-6 p-4 rounded-lg ${
                  message.type === 'error' ? 'bg-red-900/50 text-red-300' : 'bg-green-900/50 text-green-300'
                }`}>
                  {message.text}
                </div>
              )}
              
              <form onSubmit={handleSubmitTicket}>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm text-indigo-300 mb-2">
                      Categoría
                    </label>
                    <select
                      name="category"
                      value={ticketForm.category}
                      onChange={handleInputChange}
                      className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="general">General</option>
                      <option value="account">Cuenta</option>
                      <option value="payment">Pagos</option>
                      <option value="game">Juego</option>
                      <option value="influencer">Programa de Influencers</option>
                      <option value="technical">Problemas Técnicos</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm text-indigo-300 mb-2">
                      Asunto *
                    </label>
                    <input
                      type="text"
                      name="subject"
                      value={ticketForm.subject}
                      onChange={handleInputChange}
                      className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Describe brevemente tu problema"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-indigo-300 mb-2">
                      Mensaje *
                    </label>
                    <textarea
                      name="message"
                      value={ticketForm.message}
                      onChange={handleInputChange}
                      rows="6"
                      className="w-full bg-indigo-800 border border-indigo-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                      placeholder="Explica detalladamente tu problema o consulta"
                    ></textarea>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-medium py-3 px-6 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center">
                        <svg className="animate-spin h-5 w-5 mr-3 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Enviando...
                      </div>
                    ) : (
                      'Enviar Ticket'
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}
          
          {activeTab === 'myTickets' && (
            <div>
              <h3 className="text-xl font-bold text-white mb-6">Mis Tickets</h3>
              
              {tickets.length === 0 ? (
                <div className="bg-indigo-800/30 rounded-lg p-8 text-center">
                  <svg className="w-16 h-16 text-indigo-400 mx-auto mb-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 9h-2V5h2v6zm0 4h-2v-2h2v2z" fill="currentColor"/>
                  </svg>
                  <p className="text-indigo-300 mb-4">
                    No tienes tickets de soporte abiertos
                  </p>
                  <button
                    onClick={() => setActiveTab('newTicket')}
                    className="bg-indigo-700 hover:bg-indigo-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                  >
                    Crear Nuevo Ticket
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {tickets.map(ticket => (
                    <div key={ticket.id} className="bg-indigo-800/30 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-white">{ticket.subject}</h4>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          ticket.status === 'open' 
                            ? 'bg-green-900/50 text-green-300' 
                            : ticket.status === 'in-progress'
                              ? 'bg-yellow-900/50 text-yellow-300'
                              : 'bg-gray-900/50 text-gray-300'
                        }`}>
                          {ticket.status === 'open' ? 'Abierto' : 
                           ticket.status === 'in-progress' ? 'En proceso' : 'Resuelto'}
                        </span>
                      </div>
                      
                      <p className="text-sm text-indigo-300 mb-3">
                        {ticket.message.length > 100 
                          ? ticket.message.substring(0, 100) + '...' 
                          : ticket.message}
                      </p>
                      
                      <div className="flex justify-between items-center text-xs text-indigo-400">
                        <span>Categoría: {ticket.category}</span>
                        <span>{new Date(ticket.createdAt).toLocaleString()}</span>
                      </div>
                      
                      {ticket.responses.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-indigo-800">
                          <p className="text-xs text-indigo-400 mb-2">
                            Última respuesta:
                          </p>
                          <p className="text-sm text-indigo-300">
                            {ticket.responses[ticket.responses.length - 1].message.length > 100 
                              ? ticket.responses[ticket.responses.length - 1].message.substring(0, 100) + '...' 
                              : ticket.responses[ticket.responses.length - 1].message}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'faq' && (
            <div>
              <h3 className="text-xl font-bold text-white mb-6">Preguntas Frecuentes</h3>
              
              <div className="space-y-4">
                <div className="bg-indigo-800/30 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">¿Cómo funciona el juego?</h4>
                  <p className="text-indigo-300">
                    SnakeBet es un juego de serpientes multijugador donde 100 jugadores compiten por ser el último en sobrevivir. 
                    Controla tu serpiente, come para crecer y elimina a otros jugadores. El último jugador vivo gana el 90% del total apostado.
                  </p>
                </div>
                
                <div className="bg-indigo-800/30 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">¿Cómo funcionan las apuestas?</h4>
                  <p className="text-indigo-300">
                    Para jugar, debes apostar USDT o tokens SNK. El ganador recibe el 90% del total apostado, mientras que el 10% 
                    se destina a comisiones (6% para la plataforma y 4% para influencers en salas privadas).
                  </p>
                </div>
                
                <div className="bg-indigo-800/30 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">¿Cómo puedo retirar mis ganancias?</h4>
                  <p className="text-indigo-300">
                    Puedes retirar tus ganancias en USDT directamente a tu wallet desde la sección de Intercambio. 
                    Los retiros se procesan automáticamente y pueden tardar hasta 30 minutos en completarse.
                  </p>
                </div>
                
                <div className="bg-indigo-800/30 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">¿Qué es el programa de influencers?</h4>
                  <p className="text-indigo-300">
                    El programa de influencers permite a creadores de contenido crear salas personalizadas y ganar el 4% de comisión 
                    por cada partida jugada en sus salas. Para participar, debes solicitar verificación y cumplir con los requisitos.
                  </p>
                </div>
                
                <div className="bg-indigo-800/30 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">¿Qué es SnakeCoin (SNK)?</h4>
                  <p className="text-indigo-300">
                    SnakeCoin (SNK) es el token interno de la plataforma. Puedes intercambiar USDT por SNK y viceversa en cualquier momento. 
                    El token se utiliza para participar en partidas y tiene una tasa de cambio de 1:1 con USDT.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SupportPage;