import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import ConnectWallet from './components/ConnectWallet';
import ProfilePage from './components/ProfilePage';
import GameRoom from './components/GameRoom';
import CreateRoomForm from './components/CreateRoomForm';
import JoinPrivateForm from './components/JoinPrivateForm';
import InfluencerPanel from './components/InfluencerPanel';
import BecomeInfluencerPage from './components/BecomeInfluencerPage';
import SupportPage from './components/SupportPage';
import TokenExchangePage from './components/TokenExchangePage';
import { userStorage, currentRoomStorage, systemCommissionStorage } from './utilities/storage';

const App = () => {
  // Estado para la navegación
  const [currentPage, setCurrentPage] = useState('home');
  
  // Inicializar comisión del sistema si no existe
  useEffect(() => {
    const systemCommission = systemCommissionStorage.getStorage();
    if (!systemCommission.commissionRate) {
      systemCommissionStorage.setStorage({
        totalCommission: 0,
        commissionRate: 0.1 // 10% de comisión
      });
    }
  }, []);
  
  // Obtener datos del usuario y sala actual
  const user = userStorage.getStorage();
  const currentRoom = currentRoomStorage.getStorage();
  
  // Manejar la navegación
  const handleNavigate = (page) => {
    setCurrentPage(page);
  };
  
  // Manejar la conexión de wallet
  const handleConnect = () => {
    setCurrentPage('home');
  };
  
  // Manejar la salida de una sala
  const handleExitRoom = () => {
    currentRoomStorage.clearStorage();
    setCurrentPage('home');
  };
  
  // Manejar la creación de una sala
  const handleRoomCreated = (room) => {
    setCurrentPage('home');
  };
  
  // Manejar unirse a una sala privada
  const handleJoinPrivateRoom = (room) => {
    // Verificar si el usuario tiene suficiente saldo
    if (room.entryFee > 0 && user.balance < room.entryFee) {
      alert(`No tienes suficiente saldo. Necesitas ${room.entryFee} USDT para unirte a esta sala.`);
      return;
    }
    
    // Si no es sala gratuita, descontar el costo de entrada
    if (room.entryFee > 0) {
      const updatedUser = { ...user };
      updatedUser.balance -= room.entryFee;
      userStorage.setStorage(updatedUser);
      
      // Actualizar comisión del sistema (10% de la apuesta)
      const systemCommission = systemCommissionStorage.getStorage();
      const commission = room.entryFee * 0.1;
      
      // Si es sala de influencer, dividir la comisión (6% sistema, 4% influencer)
      if (room.type === 'influencer' && room.creatorInfluencerId) {
        // Aquí se procesaría la comisión del influencer (simulado)
        console.log(`Comisión para influencer: ${room.entryFee * 0.04} USDT`);
      }
      
      systemCommissionStorage.setStorage({
        ...systemCommission,
        totalCommission: systemCommission.totalCommission + commission
      });
    }
    
    // Guardar la sala actual
    currentRoomStorage.setStorage(room);
    
    // Navegar a la sala
    setCurrentPage('game');
  };
  
  // Renderizar la página actual
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'connect':
        return <ConnectWallet onConnect={handleConnect} />;
      case 'profile':
        return <ProfilePage onNavigate={handleNavigate} />;
      case 'game':
        return currentRoom ? (
          <GameRoom room={currentRoom} onExit={handleExitRoom} />
        ) : (
          <HomePage onNavigate={handleNavigate} />
        );
      case 'createRoom':
        return (
          <div className="container mx-auto px-4 py-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Crear Sala</h2>
              <button
                onClick={() => handleNavigate('home')}
                className="text-indigo-400 hover:text-white transition-colors flex items-center"
              >
                <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Volver
              </button>
            </div>
            <div className="max-w-md mx-auto">
              <CreateRoomForm 
                onRoomCreated={handleRoomCreated} 
                onCancel={() => handleNavigate('home')} 
              />
            </div>
          </div>
        );
      case 'joinPrivate':
        return (
          <div className="container mx-auto px-4 py-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Unirse a Sala Privada</h2>
              <button
                onClick={() => handleNavigate('home')}
                className="text-indigo-400 hover:text-white transition-colors flex items-center"
              >
                <svg className="w-5 h-5 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Volver
              </button>
            </div>
            <div className="max-w-md mx-auto">
              <JoinPrivateForm 
                onJoinRoom={handleJoinPrivateRoom} 
                onCancel={() => handleNavigate('home')} 
              />
            </div>
          </div>
        );
      case 'influencer':
        return <InfluencerPanel onNavigate={handleNavigate} />;
      case 'becomeInfluencer':
        return <BecomeInfluencerPage onNavigate={handleNavigate} />;
      case 'support':
        return <SupportPage onNavigate={handleNavigate} />;
      case 'exchange':
        return <TokenExchangePage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-900 to-black text-white">
      <Header onNavigate={handleNavigate} />
      
      <main className="flex-grow py-6">
        {renderPage()}
      </main>
      
      <Footer />
    </div>
  );
};

export default App;
// DONE