const gameRooms = [
  {
    id: 1,
    name: "Sala Gratuita",
    entryFee: 0,
    maxPlayers: 100,
    minPlayersToStart: 2, // Puede iniciar con solo 2 jugadores
    currentPlayers: 0,
    status: "waiting", // waiting, starting, active, finished
    startTime: null,
    type: "free", // free, standard, private, influencer, survival
    gameMode: "classic" // classic, survival
  },
  {
    id: 2,
    name: "Sala Básica",
    entryFee: 1,
    maxPlayers: 100,
    minPlayersToStart: 50, // Necesita al menos 50 jugadores para iniciar
    currentPlayers: 0,
    status: "waiting",
    startTime: null,
    type: "standard",
    gameMode: "classic"
  },
  {
    id: 3,
    name: "Sala Intermedia",
    entryFee: 3,
    maxPlayers: 100,
    minPlayersToStart: 50,
    currentPlayers: 0,
    status: "waiting",
    startTime: null,
    type: "standard",
    gameMode: "classic"
  },
  {
    id: 4,
    name: "Sala Avanzada",
    entryFee: 5,
    maxPlayers: 100,
    minPlayersToStart: 50,
    currentPlayers: 0,
    status: "waiting",
    startTime: null,
    type: "standard",
    gameMode: "classic"
  },
  {
    id: 5,
    name: "Sala VIP",
    entryFee: 10,
    maxPlayers: 100,
    minPlayersToStart: 50,
    currentPlayers: 0,
    status: "waiting",
    startTime: null,
    type: "standard",
    gameMode: "classic"
  },
  {
    id: 6,
    name: "Supervivencia Básica",
    entryFee: 1,
    maxPlayers: 100,
    minPlayersToStart: 50,
    currentPlayers: 0,
    status: "waiting",
    startTime: null,
    type: "standard",
    gameMode: "survival",
    survivalTime: 300 // 5 minutos en segundos
  },
  {
    id: 7,
    name: "Supervivencia Avanzada",
    entryFee: 5,
    maxPlayers: 100,
    minPlayersToStart: 50,
    currentPlayers: 0,
    status: "waiting",
    startTime: null,
    type: "standard",
    gameMode: "survival",
    survivalTime: 300 // 5 minutos en segundos
  }
];

export default gameRooms;