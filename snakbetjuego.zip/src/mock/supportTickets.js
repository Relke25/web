const supportTickets = [
  {
    id: 1,
    userId: "user123",
    subject: "Problema con retiro de fondos",
    message: "Intenté retirar mis ganancias pero la transacción falló.",
    status: "open", // open, in-progress, resolved
    createdAt: "2023-05-15T10:30:00Z",
    responses: []
  },
  {
    id: 2,
    userId: "user456",
    subject: "Verificación de influencer",
    message: "He enviado mis datos para verificación hace 3 días y aún no recibo respuesta.",
    status: "in-progress",
    createdAt: "2023-05-14T08:15:00Z",
    responses: [
      {
        id: 1,
        agentId: "agent001",
        message: "Estamos revisando su solicitud, le responderemos en 24 horas.",
        createdAt: "2023-05-15T09:20:00Z"
      }
    ]
  }
];

export default supportTickets;