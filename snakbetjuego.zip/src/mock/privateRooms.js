const privateRooms = [
  // Las salas privadas se crearán dinámicamente
];

export default privateRooms;