const influencers = [
  {
    id: 1,
    name: "CryptoSnake",
    walletAddress: "0x123abc...",
    totalCommission: 0,
    roomsCreated: 0
  },
  {
    id: 2,
    name: "BlockchainGamer",
    walletAddress: "0x456def...",
    totalCommission: 0,
    roomsCreated: 0
  }
];

export default influencers;