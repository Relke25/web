const gameTokens = {
  name: "SnakeCoin",
  symbol: "SNK",
  exchangeRate: 1, // 1 USDT = 1 SNK
  totalSupply: 1000000,
  circulatingSupply: 50000
};

export default gameTokens;