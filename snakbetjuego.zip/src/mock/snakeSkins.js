const snakeSkins = [
  // Básicos
  {
    id: 1,
    name: "Clásica Verde",
    headColor: "#4CAF50",
    bodyColor: "#388E3C",
    eyeColor: "#FFFFFF",
    pattern: "solid",
    rarity: "common",
    unlocked: true
  },
  {
    id: 2,
    name: "Cobra Azul",
    headColor: "#2196F3",
    bodyColor: "#1976D2",
    eyeColor: "#FFFFFF",
    pattern: "solid",
    rarity: "common",
    unlocked: true
  },
  {
    id: 3,
    name: "Víbora Roja",
    headColor: "#F44336",
    bodyColor: "#D32F2F",
    eyeColor: "#FFFFFF",
    pattern: "solid",
    rarity: "common",
    unlocked: true
  },
  {
    id: 4,
    name: "Pitón Dorada",
    headColor: "#FFD700",
    bodyColor: "#FFC107",
    eyeColor: "#212121",
    pattern: "solid",
    rarity: "rare",
    unlocked: true
  },
  {
    id: 5,
    name: "Mamba Negra",
    headColor: "#212121",
    bodyColor: "#000000",
    eyeColor: "#F44336",
    pattern: "solid",
    rarity: "uncommon",
    unlocked: true
  },
  // Patrones
  {
    id: 6,
    name: "Diamante",
    headColor: "#9C27B0",
    bodyColor: "#7B1FA2",
    eyeColor: "#FFFFFF",
    pattern: "diamond",
    rarity: "rare",
    unlocked: true
  },
  {
    id: 7,
    name: "Tigre",
    headColor: "#FF9800",
    bodyColor: "#F57C00",
    eyeColor: "#212121",
    pattern: "striped",
    rarity: "rare",
    unlocked: true
  },
  {
    id: 8,
    name: "Arcoíris",
    headColor: "#E91E63",
    bodyColor: "rainbow",
    eyeColor: "#FFFFFF",
    pattern: "gradient",
    rarity: "epic",
    unlocked: false
  },
  {
    id: 9,
    name: "Galaxia",
    headColor: "#3F51B5",
    bodyColor: "#303F9F",
    eyeColor: "#FFFFFF",
    pattern: "sparkle",
    rarity: "legendary",
    unlocked: false
  },
  {
    id: 10,
    name: "Neón",
    headColor: "#00BCD4",
    bodyColor: "#0097A7",
    eyeColor: "#FFFFFF",
    pattern: "glow",
    rarity: "epic",
    unlocked: false
  },
  // Continuar con más skins hasta 100...
  // Estos son solo los primeros 10 como ejemplo
];

// Generar 90 skins adicionales para llegar a 100
for (let i = 11; i <= 100; i++) {
  // Colores aleatorios
  const randomHeadColor = '#' + Math.floor(Math.random()*16777215).toString(16);
  const randomBodyColor = '#' + Math.floor(Math.random()*16777215).toString(16);
  const randomEyeColor = Math.random() > 0.5 ? '#FFFFFF' : '#000000';
  
  // Patrones
  const patterns = ['solid', 'striped', 'diamond', 'gradient', 'sparkle', 'glow', 'dotted', 'zigzag'];
  const randomPattern = patterns[Math.floor(Math.random() * patterns.length)];
  
  // Rareza
  const rarities = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
  const randomRarity = rarities[Math.floor(Math.random() * rarities.length)];
  
  // Desbloqueo (más común que esté bloqueado)
  const unlocked = Math.random() > 0.7;
  
  // Nombre generado
  const adjectives = ['Feroz', 'Veloz', 'Astuta', 'Sigilosa', 'Mortal', 'Venenosa', 'Elegante', 'Salvaje'];
  const types = ['Cobra', 'Pitón', 'Víbora', 'Mamba', 'Anaconda', 'Cascabel', 'Serpiente', 'Boa'];
  const randomName = `${adjectives[Math.floor(Math.random() * adjectives.length)]} ${types[Math.floor(Math.random() * types.length)]} ${i}`;
  
  snakeSkins.push({
    id: i,
    name: randomName,
    headColor: randomHeadColor,
    bodyColor: randomBodyColor,
    eyeColor: randomEyeColor,
    pattern: randomPattern,
    rarity: randomRarity,
    unlocked: unlocked
  });
}

export default snakeSkins;