// Funciones helper para localStorage
const createStorage = (key, initialValue) => {
  // Obtener valor almacenado o usar valor inicial
  const getStorage = () => {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : initialValue;
  };

  // Establecer nuevo valor
  const setStorage = (value) => {
    localStorage.setItem(key, JSON.stringify(value));
  };

  // Limpiar valor
  const clearStorage = () => {
    localStorage.removeItem(key);
  };

  return { getStorage, setStorage, clearStorage };
};

// Almacenamiento para el usuario
const userStorage = createStorage('snakeBet_user', {
  address: '',
  balance: 0,
  token: 0,
  isConnected: false,
  isInfluencer: false,
  influencerId: null,
  influencerStatus: null, // null, 'pending', 'verified', 'rejected'
  influencerWallet: null,
  pendingWithdrawals: [],
  selectedSkin: 1, // ID del skin seleccionado
  unlockedSkins: [1, 2, 3, 4, 5] // IDs de skins desbloqueados
});

// Almacenamiento para la sala actual
const currentRoomStorage = createStorage('snakeBet_currentRoom', null);

// Almacenamiento para las estadísticas del jugador
const playerStatsStorage = createStorage('snakeBet_playerStats', {
  gamesPlayed: 0,
  wins: 0,
  kills: 0,
  earnings: 0,
  survivalWins: 0
});

// Almacenamiento para salas privadas
const privateRoomsStorage = createStorage('snakeBet_privateRooms', []);

// Almacenamiento para influencers
const influencersStorage = createStorage('snakeBet_influencers', []);

// Almacenamiento para comisiones del sistema
const systemCommissionStorage = createStorage('snakeBet_systemCommission', {
  totalCommission: 0,
  commissionRate: 0.1 // 10% de comisión
});

// Almacenamiento para tickets de soporte
const supportTicketsStorage = createStorage('snakeBet_supportTickets', []);

// Almacenamiento para transacciones de tokens
const tokenTransactionsStorage = createStorage('snakeBet_tokenTransactions', []);

export { 
  userStorage, 
  currentRoomStorage, 
  playerStatsStorage, 
  privateRoomsStorage,
  influencersStorage,
  systemCommissionStorage,
  supportTicketsStorage,
  tokenTransactionsStorage
};